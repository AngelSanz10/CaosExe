import * as THREE from 'three';
import { Network } from './network.js';
import { Telemetry } from './telemetry.js';
import { Controls, Look, moveVector, orbitPosition, shortestAngleDelta, wrapAngle } from './controls.js';

const boot = JSON.parse(document.getElementById('boot').textContent);
const names = { [boot.hostId]: boot.hostNick, [boot.guestId]: boot.guestNick };

const container = document.getElementById('game');
const connectionEl = document.getElementById('connection');
const errorEl = document.getElementById('error');
const lifetime = new AbortController();
const remote = new Map();

const SPEED = 5;
const TURN_SMOOTH = 14;
const FOLLOW_SMOOTH = 18;
const REMOTE_SMOOTH = 14;
const BOUND = 35;
const FOCUS_HEIGHT = 1.5;

let leaving = false;
let localSpawned = false;
let lastFrame = performance.now();

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x090b10);

const camera = new THREE.PerspectiveCamera(55, innerWidth / innerHeight, 0.1, 500);
camera.position.set(0, 7, 12);
const focus = new THREE.Vector3(0, FOCUS_HEIGHT, 0);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
container.appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xffffff, 0x334455, 2));
const sun = new THREE.DirectionalLight(0xffffff, 2);
sun.position.set(8, 12, 6);
scene.add(sun);

const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(80, 80),
    new THREE.MeshStandardMaterial({ color: 0x202936, roughness: 0.9 })
);
floor.rotation.x = -Math.PI / 2;
scene.add(floor);
scene.add(new THREE.GridHelper(80, 40, 0x526173, 0x293241));

function makeLabel(text) {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 64;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = 'white';
    ctx.font = 'bold 28px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(text, 128, 40, 240);
    const sprite = new THREE.Sprite(
        new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(canvas), transparent: true, depthTest: false })
    );
    sprite.scale.set(2.6, 0.65, 1);
    return sprite;
}

function makePlayer(color, label) {
    const group = new THREE.Group();
    const body = new THREE.Mesh(
        new THREE.CapsuleGeometry(0.55, 1.1, 6, 12),
        new THREE.MeshStandardMaterial({ color, roughness: 0.6 })
    );
    body.position.y = 1.1;
    group.add(body);
    const nose = new THREE.Mesh(
        new THREE.BoxGeometry(0.25, 0.25, 0.5),
        new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.5 })
    );
    nose.position.set(0, 1.5, 0.6);
    group.add(nose);
    const tag = makeLabel(label);
    tag.position.set(0, 2.25, 0);
    group.add(tag);
    return group;
}

const localMesh = makePlayer(0x4da3ff, names[boot.userId] || 'TÚ');
localMesh.visible = false;
scene.add(localMesh);

function ensureRemote(id) {
    let entry = remote.get(id);
    if (entry) {
        return entry;
    }
    const mesh = makePlayer(0xff9b4a, names[id] || 'JUGADOR');
    mesh.visible = false;
    scene.add(mesh);
    entry = { mesh, pos: new THREE.Vector3(), target: new THREE.Vector3(), rotY: 0, targetRotY: 0, ready: false };
    remote.set(id, entry);
    return entry;
}

function updateRemote(dt) {
    const alpha = 1 - Math.exp(-REMOTE_SMOOTH * dt);
    for (const entry of remote.values()) {
        if (!entry.ready) continue;
        entry.pos.lerp(entry.target, alpha);
        entry.rotY += shortestAngleDelta(entry.rotY, entry.targetRotY) * alpha;
        entry.mesh.position.copy(entry.pos);
        entry.mesh.rotation.y = entry.rotY;
    }
}

function updateLocal(dt) {
    if (!localSpawned) return;
    const direction = moveVector(look.yaw, controls.forward, controls.right);
    if (!direction) return;
    localMesh.position.x = Math.max(-BOUND, Math.min(BOUND, localMesh.position.x + direction.x * SPEED * dt));
    localMesh.position.z = Math.max(-BOUND, Math.min(BOUND, localMesh.position.z + direction.z * SPEED * dt));
    const targetRot = Math.atan2(direction.x, direction.z);
    const turn = 1 - Math.exp(-TURN_SMOOTH * dt);
    localMesh.rotation.y = wrapAngle(localMesh.rotation.y + shortestAngleDelta(localMesh.rotation.y, targetRot) * turn);
}

function updateCamera(dt) {
    const follow = 1 - Math.exp(-FOLLOW_SMOOTH * dt);
    focus.x += (localMesh.position.x - focus.x) * follow;
    focus.z += (localMesh.position.z - focus.z) * follow;
    const position = orbitPosition(focus, look.yaw, look.pitch, controls.distance);
    camera.position.set(position.x, position.y, position.z);
    camera.lookAt(focus);
}

function applyState(state) {
    let remoteAge = null;
    for (const player of state.players) {
        if (player.user_id === boot.userId) {
            if (!localSpawned) {
                localMesh.position.set(player.x, player.y, player.z);
                localMesh.rotation.y = player.rotY;
                localMesh.visible = true;
                focus.set(player.x, FOCUS_HEIGHT, player.z);
                localSpawned = true;
            }
            continue;
        }
        const entry = ensureRemote(player.user_id);
        entry.target.set(player.x, player.y, player.z);
        entry.targetRotY = player.rotY;
        remoteAge = player.age_ms;
        if (!entry.ready) {
            entry.pos.copy(entry.target);
            entry.rotY = entry.targetRotY;
            entry.mesh.position.copy(entry.pos);
            entry.mesh.rotation.y = entry.rotY;
            entry.mesh.visible = true;
            entry.ready = true;
        }
    }
    telemetry.setRemoteAge(remoteAge);
    connectionEl.textContent = `Conectado · ${state.players.length}/2 jugadores`;
    connectionEl.className = state.players.length === 2 ? 'line ok' : 'line warn';
    errorEl.textContent = '';
}

function disposeScene() {
    scene.traverse((object) => {
        object.geometry?.dispose();
        const materials = Array.isArray(object.material) ? object.material : object.material ? [object.material] : [];
        for (const material of materials) {
            material.map?.dispose();
            material.dispose();
        }
    });
    scene.clear();
}

function shutdown() {
    controls.releaseLock();
    renderer.setAnimationLoop(null);
    lifetime.abort();
    network.stop();
    telemetry.dispose();
    disposeScene();
    renderer.dispose();
    renderer.forceContextLoss();
    renderer.domElement.remove();
}

async function exitToLobby(reason, { callLeave }) {
    if (leaving) return;
    leaving = true;
    if (callLeave) {
        await network.leave();
    }
    shutdown();
    window.location.replace('lobby.php' + (reason ? `?reason=${encodeURIComponent(reason)}` : ''));
}

const look = new Look();
const lockHint = document.getElementById('lockhint');
const controls = new Controls({
    element: renderer.domElement,
    look,
    signal: lifetime.signal,
    onLockChange: (locked) => lockHint.classList.toggle('hidden', locked),
});

const telemetry = new Telemetry(document.getElementById('telemetry'), renderer);

const network = new Network({
    roomId: boot.roomId,
    csrf: boot.csrf,
    csrfName: boot.csrfName,
    getPose: () => (localSpawned
        ? { x: localMesh.position.x, y: localMesh.position.y, z: localMesh.position.z, rotY: localMesh.rotation.y }
        : null),
    onState: (state) => { if (!leaving) applyState(state); },
    onSample: (sample) => { if (!leaving) telemetry.sample(sample); },
    onClosed: (reason) => { exitToLobby(reason, { callLeave: false }); },
});

const listenerOptions = { signal: lifetime.signal };
addEventListener('keydown', (event) => {
    if (event.key === 'F3') {
        event.preventDefault();
        telemetry.toggle();
    }
}, listenerOptions);
addEventListener('resize', () => {
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
}, listenerOptions);

document.getElementById('leave').addEventListener('click', () => exitToLobby(null, { callLeave: true }), listenerOptions);

function onPageExit() {
    if (!leaving) {
        network.sendDisconnectBeacon();
    }
}
addEventListener('beforeunload', onPageExit);
addEventListener('pagehide', onPageExit);
addEventListener('pageshow', (event) => {
    if (event.persisted) window.location.reload();
});

renderer.setAnimationLoop((now) => {
    if (leaving) return;
    const dt = Math.min(0.05, (now - lastFrame) / 1000);
    lastFrame = now;
    telemetry.frame(now);
    look.update(dt);
    updateLocal(dt);
    updateRemote(dt);
    updateCamera(dt);
    renderer.render(scene, camera);
});

network.start();
