const TWO_PI = Math.PI * 2;
const MAX_MOUSE_DELTA = 250;

export function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
}

export function wrapAngle(angle) {
    let wrapped = (angle + Math.PI) % TWO_PI;
    if (wrapped < 0) {
        wrapped += TWO_PI;
    }
    return wrapped - Math.PI;
}

export function shortestAngleDelta(from, to) {
    return wrapAngle(to - from);
}

/**
 * Horizontal movement relative to the camera yaw.
 * Camera sits at (sin yaw, cos yaw) around the player, so the view direction is
 * (-sin yaw, -cos yaw) and the right vector is (cos yaw, -sin yaw).
 */
export function moveVector(yaw, forward, right) {
    if (forward === 0 && right === 0) {
        return null;
    }
    const x = -Math.sin(yaw) * forward + Math.cos(yaw) * right;
    const z = -Math.cos(yaw) * forward - Math.sin(yaw) * right;
    const length = Math.hypot(x, z);
    return length > 0 ? { x: x / length, z: z / length } : null;
}

export function orbitPosition(focus, yaw, pitch, distance, minHeight = 0.4) {
    const horizontal = Math.cos(pitch) * distance;
    return {
        x: focus.x + Math.sin(yaw) * horizontal,
        y: Math.max(minHeight, focus.y + Math.sin(pitch) * distance),
        z: focus.z + Math.cos(yaw) * horizontal,
    };
}

export class Look {
    constructor({ sensitivity = 0.0022, smoothing = 30, minPitch = 0.05, maxPitch = 1.35, pitch = 0.35 } = {}) {
        this.sensitivity = sensitivity;
        this.smoothing = smoothing;
        this.minPitch = minPitch;
        this.maxPitch = maxPitch;
        this.targetYaw = 0;
        this.targetPitch = pitch;
        this.yaw = 0;
        this.pitch = pitch;
    }

    addMouse(dx, dy) {
        if (!Number.isFinite(dx) || !Number.isFinite(dy)) {
            return;
        }
        if (Math.abs(dx) > MAX_MOUSE_DELTA || Math.abs(dy) > MAX_MOUSE_DELTA) {
            return;
        }
        this.targetYaw -= dx * this.sensitivity;
        this.targetPitch = clamp(this.targetPitch + dy * this.sensitivity, this.minPitch, this.maxPitch);
    }

    update(dt) {
        const alpha = 1 - Math.exp(-this.smoothing * dt);
        this.yaw += (this.targetYaw - this.yaw) * alpha;
        this.pitch += (this.targetPitch - this.pitch) * alpha;
    }
}

const FORWARD = ['KeyW', 'ArrowUp'];
const BACKWARD = ['KeyS', 'ArrowDown'];
const LEFT = ['KeyA', 'ArrowLeft'];
const RIGHT = ['KeyD', 'ArrowRight'];

export class Controls {
    constructor({ element, look, signal, onLockChange = () => {}, minDistance = 3, maxDistance = 14, distance = 7 }) {
        this.element = element;
        this.look = look;
        this.onLockChange = onLockChange;
        this.minDistance = minDistance;
        this.maxDistance = maxDistance;
        this.distance = distance;
        this.keys = new Set();
        this.locked = false;

        const options = { signal };
        addEventListener('keydown', (event) => this.keys.add(event.code), options);
        addEventListener('keyup', (event) => this.keys.delete(event.code), options);
        addEventListener('blur', () => this.keys.clear(), options);

        element.addEventListener('click', () => this.requestLock(), options);
        element.addEventListener('wheel', (event) => {
            this.distance = clamp(this.distance + Math.sign(event.deltaY) * 0.6, this.minDistance, this.maxDistance);
        }, { signal, passive: true });

        document.addEventListener('pointerlockchange', () => {
            this.locked = document.pointerLockElement === this.element;
            if (!this.locked) {
                this.keys.clear();
            }
            this.onLockChange(this.locked);
        }, options);
        document.addEventListener('mousemove', (event) => {
            if (this.locked) {
                this.look.addMouse(event.movementX, event.movementY);
            }
        }, options);
    }

    requestLock() {
        if (this.locked) {
            return;
        }
        try {
            this.element.requestPointerLock();
        } catch (_) {}
    }

    releaseLock() {
        if (document.pointerLockElement === this.element) {
            document.exitPointerLock();
        }
    }

    axis(positive, negative) {
        const on = (codes) => codes.some((code) => this.keys.has(code));
        return (on(positive) ? 1 : 0) - (on(negative) ? 1 : 0);
    }

    get forward() {
        return this.axis(FORWARD, BACKWARD);
    }

    get right() {
        return this.axis(RIGHT, LEFT);
    }
}
