const PULL_MS = 150;
const PUSH_MS = 100;
const REQUEST_TIMEOUT_MS = 4000;
const MAX_OUTAGE_MS = 12000;
const RETRY_MS = 500;

export class NetError extends Error {
    constructor(kind, message, extra = {}) {
        super(message);
        this.kind = kind;
        Object.assign(this, extra);
    }
}

export class Network {
    constructor({ roomId, csrf, csrfName, getPose, onState, onSample, onClosed }) {
        this.roomId = roomId;
        this.csrf = csrf;
        this.csrfName = csrfName;
        this.getPose = getPose;
        this.onState = onState;
        this.onSample = onSample;
        this.onClosed = onClosed;
        this.stopped = false;
        this.failSince = null;
        this.pullTimer = null;
        this.pushTimer = null;
        this.pushing = false;
        this.beaconSent = false;
    }

    start() {
        this.pull();
        this.pushTimer = setInterval(() => this.push(), PUSH_MS);
    }

    stop() {
        this.stopped = true;
        clearTimeout(this.pullTimer);
        clearInterval(this.pushTimer);
        this.pullTimer = null;
        this.pushTimer = null;
    }

    async request(url, options = {}) {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
        const startedAt = performance.now();
        let response;
        try {
            response = await fetch(url, {
                credentials: 'same-origin',
                cache: 'no-store',
                signal: controller.signal,
                ...options,
            });
        } catch (error) {
            throw new NetError('network', error.name === 'AbortError' ? 'Tiempo de espera agotado' : 'Sin conexión');
        } finally {
            clearTimeout(timeout);
        }
        const rtt = performance.now() - startedAt;

        let data = null;
        try {
            data = await response.json();
        } catch (_) {
            throw new NetError('network', 'Respuesta inválida del servidor');
        }

        if (response.status === 401) {
            throw new NetError('auth', 'Sesión expirada');
        }
        if (response.status === 403 && data.code === 'csrf') {
            throw new NetError('auth', 'Token de seguridad inválido');
        }
        if (response.status === 403 || response.status === 409) {
            throw new NetError('closed', data.errors?.[0] || 'Partida no disponible', { endReason: data.end_reason || null, code: data.code });
        }
        if (!response.ok || !data.success) {
            throw new NetError('server', data.errors?.[0] || 'Error del servidor');
        }

        return { data, rtt };
    }

    form(action, fields = {}) {
        const body = new FormData();
        body.append('action', action);
        body.append(this.csrfName, this.csrf);
        for (const [key, value] of Object.entries(fields)) {
            body.append(key, String(value));
        }
        return body;
    }

    handleFailure(error) {
        if (this.stopped) {
            return;
        }
        if (error.kind === 'auth' || error.kind === 'closed') {
            this.stop();
            this.onClosed(error.kind === 'auth' ? 'session' : 'room_closed', error);
            return;
        }
        this.failSince ??= performance.now();
        if (performance.now() - this.failSince >= MAX_OUTAGE_MS) {
            this.stop();
            this.onClosed('network', error);
        }
    }

    async pull() {
        if (this.stopped) {
            return;
        }
        const startedAt = performance.now();
        try {
            const { data, rtt } = await this.request(`api/room.php?action=state&room_id=${encodeURIComponent(this.roomId)}`);
            if (this.stopped) {
                return;
            }
            this.failSince = null;
            this.onSample({ kind: 'pull', rtt, srv: data.srv_ms, ok: true });
            this.onState(data.state);
        } catch (error) {
            this.onSample({ kind: 'pull', ok: false });
            this.handleFailure(error);
        } finally {
            if (!this.stopped) {
                const elapsed = performance.now() - startedAt;
                const wait = this.failSince === null ? Math.max(0, PULL_MS - elapsed) : RETRY_MS;
                this.pullTimer = setTimeout(() => this.pull(), wait);
            }
        }
    }

    async push() {
        if (this.stopped || this.pushing) {
            return;
        }
        const pose = this.getPose();
        if (!pose) {
            return;
        }
        this.pushing = true;
        try {
            const { rtt } = await this.request('api/room.php?action=update', {
                method: 'POST',
                body: this.form('update', { room_id: this.roomId, x: pose.x, y: pose.y, z: pose.z, rotY: pose.rotY }),
            });
            this.onSample({ kind: 'push', rtt, ok: true });
        } catch (error) {
            this.onSample({ kind: 'push', ok: false });
            this.handleFailure(error);
        } finally {
            this.pushing = false;
        }
    }

    async leave() {
        this.stop();
        try {
            await this.request('api/room.php?action=leave', {
                method: 'POST',
                body: this.form('leave'),
                keepalive: true,
            });
        } catch (_) {}
    }

    sendDisconnectBeacon() {
        if (this.beaconSent) {
            return;
        }
        this.beaconSent = true;
        this.stop();
        navigator.sendBeacon('api/room.php?action=disconnect', this.form('disconnect'));
    }
}
