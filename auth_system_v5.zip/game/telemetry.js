export class Ring {
    constructor(size) {
        this.size = size;
        this.items = [];
    }

    push(value) {
        this.items.push(value);
        if (this.items.length > this.size) {
            this.items.shift();
        }
    }

    get length() {
        return this.items.length;
    }
}

export function mean(values) {
    return values.length ? values.reduce((a, b) => a + b, 0) / values.length : 0;
}

export function percentile(values, p) {
    if (!values.length) {
        return 0;
    }
    const sorted = [...values].sort((a, b) => a - b);
    const index = Math.min(sorted.length - 1, Math.max(0, Math.ceil((p / 100) * sorted.length) - 1));
    return sorted[index];
}

export function jitter(values) {
    if (values.length < 2) {
        return 0;
    }
    let total = 0;
    for (let i = 1; i < values.length; i++) {
        total += Math.abs(values[i] - values[i - 1]);
    }
    return total / (values.length - 1);
}

export function quality(pingMs, lossPct, hasData) {
    if (!hasData) {
        return { label: 'Midiendo…', level: 'warn' };
    }
    if (lossPct >= 10 || pingMs >= 250) {
        return { label: 'Mala', level: 'bad' };
    }
    if (lossPct >= 3 || pingMs >= 150) {
        return { label: 'Regular', level: 'warn' };
    }
    if (pingMs >= 80) {
        return { label: 'Buena', level: 'ok' };
    }
    return { label: 'Excelente', level: 'ok' };
}

const ROWS = [
    ['conn', 'Conexión'],
    ['ping', 'Ping'],
    ['jitter', 'Jitter'],
    ['srv', 'Servidor'],
    ['loss', 'Pérdida'],
    ['age', 'Datos rival'],
    ['rate', 'Red ↓/↑'],
    ['fps', 'FPS'],
    ['frame', 'Frame'],
    ['gpu', 'Draw / Tris'],
    ['mem', 'Geo / Tex'],
    ['heap', 'Heap JS'],
];

export class Telemetry {
    constructor(container, renderer) {
        this.renderer = renderer;
        this.frames = new Ring(120);
        this.rtts = new Ring(40);
        this.srv = new Ring(40);
        this.outcomes = new Ring(60);
        this.remoteAgeMs = null;
        this.rx = 0;
        this.tx = 0;
        this.lastFrame = 0;
        this.lastRender = performance.now();
        this.detailed = true;
        this.cells = new Map();

        this.root = document.createElement('div');
        this.root.className = 'tele';
        this.summary = document.createElement('div');
        this.summary.className = 'tele-summary';
        this.root.appendChild(this.summary);

        this.table = document.createElement('div');
        this.table.className = 'tele-table';
        for (const [key, label] of ROWS) {
            const row = document.createElement('div');
            const name = document.createElement('span');
            const value = document.createElement('span');
            name.textContent = label;
            row.append(name, value);
            this.table.appendChild(row);
            this.cells.set(key, value);
        }
        this.root.appendChild(this.table);

        const hint = document.createElement('div');
        hint.className = 'tele-hint';
        hint.textContent = 'F3 · mostrar/ocultar detalle';
        this.root.appendChild(hint);
        container.appendChild(this.root);

        this.timer = setInterval(() => this.render(), 500);
    }

    frame(now) {
        if (this.lastFrame) {
            this.frames.push(now - this.lastFrame);
        }
        this.lastFrame = now;
    }

    sample({ rtt, srv, ok, kind }) {
        this.outcomes.push(ok ? 0 : 1);
        if (!ok) {
            return;
        }
        if (kind === 'pull') {
            this.rtts.push(rtt);
            this.rx++;
            if (typeof srv === 'number') {
                this.srv.push(srv);
            }
        } else {
            this.tx++;
        }
    }

    setRemoteAge(ms) {
        this.remoteAgeMs = ms;
    }

    toggle() {
        this.detailed = !this.detailed;
        this.table.style.display = this.detailed ? '' : 'none';
    }

    set(key, text, level) {
        const cell = this.cells.get(key);
        if (!cell) {
            return;
        }
        cell.textContent = text;
        cell.className = level || '';
    }

    render() {
        const now = performance.now();
        const seconds = Math.max(0.001, (now - this.lastRender) / 1000);
        this.lastRender = now;

        const frameTimes = this.frames.items;
        const avgFrame = mean(frameTimes);
        const fps = avgFrame > 0 ? 1000 / avgFrame : 0;
        const lowFps = frameTimes.length ? 1000 / percentile(frameTimes, 99) : 0;

        const ping = percentile(this.rtts.items, 50);
        const jit = jitter(this.rtts.items);
        const srvMs = mean(this.srv.items);
        const loss = this.outcomes.length ? (mean(this.outcomes.items) * 100) : 0;
        const q = quality(ping, loss, this.rtts.length > 0);

        this.summary.textContent = `${Math.round(fps)} FPS · ${this.rtts.length ? Math.round(ping) + ' ms' : '— ms'} · ${q.label}`;
        this.summary.className = 'tele-summary ' + q.level;

        this.set('conn', q.label, q.level);
        this.set('ping', this.rtts.length ? `${ping.toFixed(0)} ms (mín ${Math.min(...this.rtts.items).toFixed(0)} / máx ${Math.max(...this.rtts.items).toFixed(0)})` : '—', ping >= 150 ? 'warn' : 'ok');
        this.set('jitter', `${jit.toFixed(1)} ms`, jit >= 40 ? 'warn' : 'ok');
        this.set('srv', this.srv.length ? `${srvMs.toFixed(1)} ms proceso` : '—', srvMs >= 80 ? 'warn' : 'ok');
        this.set('loss', `${loss.toFixed(1)} %`, loss >= 3 ? 'warn' : 'ok');
        this.set('age', this.remoteAgeMs === null ? '—' : `${this.remoteAgeMs} ms`, this.remoteAgeMs !== null && this.remoteAgeMs > 1500 ? 'warn' : 'ok');
        this.set('rate', `${(this.rx / seconds).toFixed(1)} / ${(this.tx / seconds).toFixed(1)} por s`);
        this.set('fps', `${fps.toFixed(0)} (1% bajo: ${lowFps.toFixed(0)})`, fps > 0 && fps < 30 ? 'warn' : 'ok');
        this.set('frame', `${avgFrame.toFixed(1)} ms`);

        const info = this.renderer.info;
        this.set('gpu', `${info.render.calls} / ${info.render.triangles}`);
        this.set('mem', `${info.memory.geometries} / ${info.memory.textures}`);

        const heap = performance.memory?.usedJSHeapSize;
        this.set('heap', heap ? `${(heap / 1048576).toFixed(1)} MB` : 'no disponible');

        this.rx = 0;
        this.tx = 0;
    }

    dispose() {
        clearInterval(this.timer);
        this.root.remove();
    }
}
