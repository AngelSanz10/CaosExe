<?php
/**
 * Protected area – authenticated user session
 * Contains all necessary user data from a professional users table.
 */

declare(strict_types=1);

require_once __DIR__ . '/includes/Auth.php';

Auth::startSession();
$auth = new Auth();

if (!$auth->check()) {
    setFlash('error', 'Debes iniciar sesión para acceder.');
    redirect('login.php');
}

$user = $auth->user();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sesión activa</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>Sesión activa</h1>
            <p class="subtitle">
                Estado: <span class="badge badge-active">Activo</span>
            </p>

            <ul class="user-info">
                <li>
                    <span>ID</span>
                    <span><?= e((string) $user['id']) ?></span>
                </li>
                <li>
                    <span>Nickname</span>
                    <span><?= e($user['nickname']) ?></span>
                </li>
                <li>
                    <span>Correo</span>
                    <span><?= e($user['email']) ?></span>
                </li>
                <li>
                    <span>Token de sesión</span>
                    <span style="font-family: monospace; font-size: 0.75rem; word-break: break-all;">
                        <?= e(substr($user['session_token'], 0, 16)) ?>…
                    </span>
                </li>
                <li>
                    <span>Inicio de sesión</span>
                    <span><?= e($user['logged_in_at']) ?> UTC</span>
                </li>
            </ul>

            <p class="subtitle" style="margin-bottom: 1rem;">
                Sistema de autenticación listo. Continúa al lobby para emparejamiento cooperativo.
            </p>

            <a href="lobby.php" class="btn" style="margin-bottom: 0.75rem;">Ir al lobby</a>
            <form method="post" action="logout.php">
                <input type="hidden" name="<?= e(CSRF_TOKEN_NAME) ?>" value="<?= e(csrfToken()) ?>">
                <button type="submit" class="btn btn-secondary">Cerrar sesión</button>
            </form>
        </div>
    </div>
</body>
</html>
