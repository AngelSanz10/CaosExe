-- Migración para BD ya existente: Partida rápida + auto-start
-- Ejecutar una sola vez en phpMyAdmin

ALTER TABLE game_rooms
    ADD COLUMN match_type ENUM('code','quick') NOT NULL DEFAULT 'code'
        COMMENT 'code = manual invite; quick = matchmaking'
        AFTER status,
    ADD COLUMN auto_start_at DATETIME NULL DEFAULT NULL
        COMMENT 'UTC instant when a quick match should auto-start'
        AFTER guest_id,
    ADD KEY idx_game_rooms_match (match_type, status);
