-- Migración v2: heartbeats anti-fantasma, motivo de cierre, precisión de ms y límite de login.
-- Ejecutar UNA sola vez sobre una BD existente (después de migrate_quick_match.sql si aplica).

ALTER TABLE game_rooms
    ADD COLUMN host_seen  DATETIME(3) NULL DEFAULT NULL AFTER auto_start_at,
    ADD COLUMN guest_seen DATETIME(3) NULL DEFAULT NULL AFTER host_seen,
    ADD COLUMN end_reason VARCHAR(24) NULL DEFAULT NULL AFTER finished_at,
    ADD KEY idx_game_rooms_status_updated (status, updated_at);

ALTER TABLE game_room_players
    MODIFY last_seen DATETIME(3) NOT NULL;

CREATE TABLE IF NOT EXISTS login_attempts (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    ip          VARBINARY(16)   NOT NULL,
    email_hash  CHAR(64)        NOT NULL,
    created_at  DATETIME        NOT NULL,
    PRIMARY KEY (id),
    KEY idx_login_attempts_ip (ip, created_at),
    KEY idx_login_attempts_email (email_hash, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
