-- Professional users + cooperative game rooms
-- Compatible with MySQL 8+ / MariaDB 10.5+

CREATE DATABASE IF NOT EXISTS game_auth
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE game_auth;

CREATE TABLE IF NOT EXISTS users (
    id              BIGINT UNSIGNED     NOT NULL AUTO_INCREMENT,
    email           VARCHAR(255)        NOT NULL,
    nickname        VARCHAR(32)         NOT NULL,
    password_hash   VARCHAR(255)        NOT NULL,
    session_token   CHAR(64)            NULL DEFAULT NULL COMMENT 'Current valid session token (hex)',
    is_active       TINYINT(1)          NOT NULL DEFAULT 1,
    last_login      DATETIME            NULL DEFAULT NULL,
    created_at      DATETIME            NOT NULL,
    updated_at      DATETIME            NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_users_email (email),
    UNIQUE KEY uq_users_nickname (nickname),
    KEY idx_users_session_token (session_token),
    KEY idx_users_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Cooperative rooms (exactly 2 players)
CREATE TABLE IF NOT EXISTS game_rooms (
    id              BIGINT UNSIGNED     NOT NULL AUTO_INCREMENT,
    code            CHAR(6)             NOT NULL COMMENT 'Public join code (uppercase)',
    status          ENUM('waiting','ready','playing','finished','cancelled')
                                        NOT NULL DEFAULT 'waiting',
    match_type      ENUM('code','quick') NOT NULL DEFAULT 'code'
                                        COMMENT 'code = manual invite; quick = matchmaking',
    host_id         BIGINT UNSIGNED     NOT NULL,
    guest_id        BIGINT UNSIGNED     NULL DEFAULT NULL,
    auto_start_at   DATETIME            NULL DEFAULT NULL
                                        COMMENT 'UTC instant when a quick match should auto-start',
    host_seen       DATETIME(3)         NULL DEFAULT NULL,
    guest_seen      DATETIME(3)         NULL DEFAULT NULL,
    created_at      DATETIME            NOT NULL,
    updated_at      DATETIME            NOT NULL,
    started_at      DATETIME            NULL DEFAULT NULL,
    finished_at     DATETIME            NULL DEFAULT NULL,
    end_reason      VARCHAR(24)         NULL DEFAULT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_game_rooms_code (code),
    KEY idx_game_rooms_status (status),
    KEY idx_game_rooms_status_updated (status, updated_at),
    KEY idx_game_rooms_match (match_type, status),
    KEY idx_game_rooms_host (host_id),
    KEY idx_game_rooms_guest (guest_id),
    CONSTRAINT fk_rooms_host  FOREIGN KEY (host_id)  REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_rooms_guest FOREIGN KEY (guest_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Shared runtime state for both players inside a match
CREATE TABLE IF NOT EXISTS game_room_players (
    room_id         BIGINT UNSIGNED NOT NULL,
    user_id         BIGINT UNSIGNED NOT NULL,
    player_slot     TINYINT UNSIGNED NOT NULL,
    pos_x           DOUBLE NOT NULL DEFAULT 0,
    pos_y           DOUBLE NOT NULL DEFAULT 0,
    pos_z           DOUBLE NOT NULL DEFAULT 0,
    rot_y           DOUBLE NOT NULL DEFAULT 0,
    last_seen       DATETIME(3) NOT NULL,
    PRIMARY KEY (room_id, user_id),
    UNIQUE KEY uq_room_player_slot (room_id, player_slot),
    KEY idx_room_players_seen (room_id, last_seen),
    CONSTRAINT fk_room_players_room FOREIGN KEY (room_id) REFERENCES game_rooms(id) ON DELETE CASCADE,
    CONSTRAINT fk_room_players_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_attempts (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    ip          VARBINARY(16)   NOT NULL,
    email_hash  CHAR(64)        NOT NULL,
    created_at  DATETIME        NOT NULL,
    PRIMARY KEY (id),
    KEY idx_login_attempts_ip (ip, created_at),
    KEY idx_login_attempts_email (email_hash, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
