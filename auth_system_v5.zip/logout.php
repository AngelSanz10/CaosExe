<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/Auth.php';
require_once __DIR__ . '/includes/GameRoom.php';

Auth::startSession();
$auth = new Auth();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !validateCsrf($_POST[CSRF_TOKEN_NAME] ?? null)) {
    redirect($auth->check() ? 'session.php' : 'index.php');
}

$user = $auth->user();
if ($user !== null) {
    try {
        (new GameRoom())->leave((int) $user['id']);
    } catch (Throwable $e) {
        error_log('logout leave error: ' . $e->getMessage());
    }
}

$auth->logout();

Auth::startSession();
setFlash('success', 'Has cerrado sesión correctamente.');
redirect('index.php');
