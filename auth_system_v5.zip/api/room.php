<?php

declare(strict_types=1);

$startedAt = hrtime(true);

require_once __DIR__ . '/../includes/Auth.php';
require_once __DIR__ . '/../includes/GameRoom.php';

Auth::startSession();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');

function respond(array $data, int $status = 200): never
{
    global $startedAt;
    $data['srv_ms'] = round((hrtime(true) - $startedAt) / 1e6, 1);
    jsonResponse($data, $status);
}

const ROUTES = [
    'create'     => 'POST',
    'join'       => 'POST',
    'quick'      => 'POST',
    'leave'      => 'POST',
    'start'      => 'POST',
    'disconnect' => 'POST',
    'update'     => 'POST',
    'state'      => 'GET',
    'status'     => 'GET',
];

try {
    $action = $_GET['action'] ?? $_POST['action'] ?? '';
    if (!is_string($action) || !isset(ROUTES[$action])) {
        respond(['success' => false, 'code' => 'bad_action', 'errors' => ['Acción no válida.']], 400);
    }

    $auth = new Auth();
    $user = $auth->user();
    if ($user === null) {
        respond(['success' => false, 'code' => 'unauthenticated', 'errors' => ['No autenticado.']], 401);
    }

    if ($_SERVER['REQUEST_METHOD'] !== ROUTES[$action]) {
        respond(['success' => false, 'code' => 'bad_method', 'errors' => ['Método no permitido.']], 405);
    }

    if (ROUTES[$action] === 'POST') {
        $token = $_POST[CSRF_TOKEN_NAME] ?? null;
        if (!is_string($token) || !validateCsrf($token)) {
            respond(['success' => false, 'code' => 'csrf', 'errors' => ['Token CSRF inválido.']], 403);
        }
    }

    // Release the session lock: nothing below writes to $_SESSION, and holding it
    // would serialize every poll/update request of the same player.
    session_write_close();

    $userId      = (int) $user['id'];
    $userPayload = ['id' => $userId, 'nickname' => $user['nickname']];
    $rooms       = new GameRoom();

    switch ($action) {
        case 'create':
            $result = $rooms->create($userId);
            break;

        case 'join':
            $result = $rooms->join($userId, (string) ($_POST['code'] ?? ''));
            break;

        case 'quick':
            $result = $rooms->quickMatch($userId);
            break;

        case 'leave':
            $result = $rooms->leave($userId);
            break;

        case 'disconnect':
            $rooms->markDisconnecting($userId);
            $result = ['success' => true];
            break;

        case 'start':
            $result = $rooms->start($userId, (int) ($_POST['room_id'] ?? 0));
            break;

        case 'update':
            $ok = $rooms->updatePlayerState(
                (int) ($_POST['room_id'] ?? 0),
                $userId,
                (float) ($_POST['x'] ?? 0),
                (float) ($_POST['y'] ?? 0),
                (float) ($_POST['z'] ?? 0),
                (float) ($_POST['rotY'] ?? 0)
            );
            respond(
                $ok
                    ? ['success' => true, 'user' => $userPayload]
                    : ['success' => false, 'code' => 'room_closed', 'errors' => ['Partida no disponible.'], 'user' => $userPayload],
                $ok ? 200 : 409
            );

        case 'state':
            $state = $rooms->getState((int) ($_GET['room_id'] ?? 0), $userId);
            if ($state === null) {
                respond(['success' => false, 'code' => 'forbidden', 'errors' => ['Estado no disponible.']], 403);
            }
            if ($state['status'] !== 'playing') {
                respond([
                    'success'    => false,
                    'code'       => 'room_closed',
                    'end_reason' => $state['end_reason'],
                    'errors'     => ['La partida ha terminado.'],
                    'user'       => $userPayload,
                ], 409);
            }
            respond(['success' => true, 'state' => $state, 'user' => $userPayload]);

        case 'status':
            respond(['success' => true, 'room' => $rooms->poll($userId), 'user' => $userPayload]);
    }

    $result['user'] = $userPayload;
    respond($result, ($result['success'] ?? false) ? 200 : 400);
} catch (Throwable $e) {
    error_log('api/room.php error: ' . $e->getMessage());
    respond(['success' => false, 'code' => 'server_error', 'errors' => ['Error interno del servidor.']], 500);
}
