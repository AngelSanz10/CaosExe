<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

final class GameRoom
{
    public const LOBBY_STALE_SECONDS = 20;
    public const PLAYING_STALE_SECONDS = 20;
    public const DISCONNECT_GRACE_SECONDS = 6;

    private const QUICK_COUNTDOWN_SECONDS = 3;
    private const MAX_SPEED = 9.0;
    private const MAX_STEP_SECONDS = 1.0;
    private const MIN_UPDATE_INTERVAL = 0.04;

    private const SELECT_ROOM = 'SELECT r.*, h.nickname AS host_nick, g.nickname AS guest_nick
        FROM game_rooms r
        JOIN users h ON h.id = r.host_id
        LEFT JOIN users g ON g.id = r.guest_id';

    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    /**
     * @return array{success: bool, room?: array, errors?: string[]}
     */
    public function create(int $hostId, string $matchType = 'code'): array
    {
        $matchType = $matchType === 'quick' ? 'quick' : 'code';
        $this->reapStale();
        $this->leaveAllActive($hostId);

        $now  = $this->now();
        $seen = $this->nowMs();
        $stmt = $this->db->prepare(
            "INSERT INTO game_rooms (code, status, match_type, host_id, host_seen, created_at, updated_at)
             VALUES (?, 'waiting', ?, ?, ?, ?, ?)"
        );

        $roomId = 0;
        for ($attempt = 0; $attempt < 5 && $roomId === 0; $attempt++) {
            try {
                $stmt->execute([$this->generateCode(), $matchType, $hostId, $seen, $now, $now]);
                $roomId = (int) $this->db->lastInsertId();
            } catch (PDOException $e) {
                if ($e->getCode() !== '23000') {
                    throw $e;
                }
            }
        }

        $room = $roomId > 0 ? $this->findById($roomId) : null;

        return $room
            ? ['success' => true, 'room' => $room]
            : ['success' => false, 'errors' => ['No se pudo crear la sala.']];
    }

    /**
     * @param bool $internal true only for server-side matchmaking (may join quick rooms)
     * @return array{success: bool, room?: array, errors?: string[]}
     */
    public function join(int $userId, string $code, bool $internal = false): array
    {
        $code = strtoupper(trim($code));
        if (!preg_match('/^[A-Z0-9]{6}$/', $code)) {
            return ['success' => false, 'errors' => ['Código de sala inválido.']];
        }

        $this->reapStale();
        $this->leaveAllActive($userId);

        $this->db->beginTransaction();
        try {
            $stmt = $this->db->prepare('SELECT * FROM game_rooms WHERE code = ? LIMIT 1 FOR UPDATE');
            $stmt->execute([$code]);
            $room = $stmt->fetch();

            if (!$room || (!$internal && $room['match_type'] === 'quick')) {
                $this->db->rollBack();
                return ['success' => false, 'errors' => ['Sala no encontrada.']];
            }
            if ($room['status'] !== 'waiting') {
                $this->db->rollBack();
                return ['success' => false, 'errors' => ['La sala ya no acepta jugadores.']];
            }
            if ((int) $room['host_id'] === $userId) {
                $this->db->rollBack();
                return ['success' => false, 'errors' => ['Ya eres el anfitrión de esta sala.']];
            }
            if ($room['guest_id'] !== null) {
                $this->db->rollBack();
                return ['success' => false, 'errors' => ['La sala está llena.']];
            }

            $autoStartAt = $room['match_type'] === 'quick'
                ? (new DateTimeImmutable('now', new DateTimeZone('UTC')))
                    ->modify('+' . self::QUICK_COUNTDOWN_SECONDS . ' seconds')
                    ->format('Y-m-d H:i:s')
                : null;

            $upd = $this->db->prepare(
                "UPDATE game_rooms
                 SET guest_id = ?, guest_seen = ?, status = 'ready', auto_start_at = ?, updated_at = ?
                 WHERE id = ? AND status = 'waiting' AND guest_id IS NULL"
            );
            $upd->execute([$userId, $this->nowMs(), $autoStartAt, $this->now(), $room['id']]);

            if ($upd->rowCount() === 0) {
                $this->db->rollBack();
                return ['success' => false, 'errors' => ['No se pudo unir a la sala.']];
            }

            $this->db->commit();
            $fresh = $this->findById((int) $room['id']);
            return $fresh
                ? ['success' => true, 'room' => $fresh]
                : ['success' => false, 'errors' => ['Error al cargar la sala.']];
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            error_log('GameRoom::join error: ' . $e->getMessage());
            return ['success' => false, 'errors' => ['Error interno al unirse.']];
        }
    }

    /**
     * @return array{success: bool, room?: array, errors?: string[]}
     */
    public function quickMatch(int $userId): array
    {
        $this->reapStale();
        $this->leaveAllActive($userId);

        $stmt = $this->db->prepare(
            "SELECT code FROM game_rooms
             WHERE status = 'waiting' AND match_type = 'quick' AND guest_id IS NULL AND host_id <> ?
             ORDER BY id ASC
             LIMIT 1"
        );
        $stmt->execute([$userId]);
        $candidate = $stmt->fetch();

        if ($candidate) {
            $joined = $this->join($userId, $candidate['code'], true);
            if ($joined['success']) {
                return $joined;
            }
        }

        return $this->create($userId, 'quick');
    }

    /**
     * Heartbeat + reaping + quick-match reconciliation. Called by the lobby poll.
     */
    public function poll(int $userId): ?array
    {
        $this->touchLobby($userId);
        $this->reapStale();

        $room = $this->findActiveByUser($userId);
        if (!$room) {
            return null;
        }

        if (
            $room['match_type'] === 'quick'
            && $room['status'] === 'waiting'
            && (int) ($room['host']['id'] ?? 0) === $userId
        ) {
            $merged = $this->mergeIntoOlderQuickRoom($room, $userId);
            if ($merged !== null) {
                return $merged;
            }
        }

        return $room;
    }

    public function leave(int $userId): array
    {
        $room = $this->findActiveByUser($userId);
        if (!$room) {
            return ['success' => true];
        }

        $roomId = (int) $room['id'];
        $isHost = (int) ($room['host']['id'] ?? 0) === $userId;

        if ($isHost || $room['status'] === 'playing') {
            $this->cancelRoom($roomId, $isHost ? 'host_left' : 'guest_left');
            return ['success' => true];
        }

        $stmt = $this->db->prepare(
            "UPDATE game_rooms
             SET guest_id = NULL, guest_seen = NULL, status = 'waiting', auto_start_at = NULL, updated_at = ?
             WHERE id = ? AND guest_id = ? AND status IN ('waiting', 'ready')"
        );
        $stmt->execute([$this->now(), $roomId, $userId]);

        if ($stmt->rowCount() === 0) {
            $this->cancelRoom($roomId, 'guest_left');
        }

        return ['success' => true];
    }

    /**
     * Soft disconnect (tab close / reload beacon). The player keeps a short grace window
     * to come back; if they do not, the reaper releases the room.
     */
    public function markDisconnecting(int $userId): void
    {
        $seen = $this->ts(microtime(true) - (self::LOBBY_STALE_SECONDS - self::DISCONNECT_GRACE_SECONDS));
        $seenPlaying = $this->ts(microtime(true) - (self::PLAYING_STALE_SECONDS - self::DISCONNECT_GRACE_SECONDS));

        $this->db->prepare("UPDATE game_rooms SET host_seen = ? WHERE host_id = ? AND status IN ('waiting', 'ready')")
            ->execute([$seen, $userId]);
        $this->db->prepare("UPDATE game_rooms SET guest_seen = ? WHERE guest_id = ? AND status = 'ready'")
            ->execute([$seen, $userId]);
        $this->db->prepare(
            "UPDATE game_room_players p
             JOIN game_rooms r ON r.id = p.room_id
             SET p.last_seen = ?
             WHERE p.user_id = ? AND r.status = 'playing'"
        )->execute([$seenPlaying, $userId]);
    }

    public function start(int $userId, int $roomId): array
    {
        if ($roomId <= 0 || $userId <= 0) {
            return ['success' => false, 'errors' => ['Datos de sala inválidos.']];
        }

        try {
            $this->db->beginTransaction();

            $stmt = $this->db->prepare(
                'SELECT id, status, host_id, guest_id FROM game_rooms WHERE id = ? LIMIT 1 FOR UPDATE'
            );
            $stmt->execute([$roomId]);
            $room = $stmt->fetch();

            if (!$room) {
                $this->db->rollBack();
                return ['success' => false, 'errors' => ['Sala no encontrada.']];
            }

            $hostId  = (int) $room['host_id'];
            $guestId = $room['guest_id'] !== null ? (int) $room['guest_id'] : 0;

            if ($hostId !== $userId) {
                $this->db->rollBack();
                return ['success' => false, 'errors' => ['Solo el anfitrión puede iniciar.']];
            }
            if ($room['status'] !== 'ready') {
                $this->db->rollBack();
                return ['success' => false, 'errors' => ['La sala no está lista.']];
            }
            if ($guestId <= 0 || $guestId === $hostId) {
                $this->db->rollBack();
                return ['success' => false, 'errors' => ['La sala necesita dos jugadores.']];
            }

            $this->initializePlayers($roomId, $hostId, $guestId, $this->nowMs());

            $update = $this->db->prepare(
                "UPDATE game_rooms SET status = 'playing', started_at = ?, updated_at = ?
                 WHERE id = ? AND status = 'ready'"
            );
            $now = $this->now();
            $update->execute([$now, $now, $roomId]);

            if ($update->rowCount() !== 1) {
                $this->db->rollBack();
                return ['success' => false, 'errors' => ['No se pudo iniciar la partida.']];
            }

            $this->db->commit();

            $fresh = $this->findById($roomId);
            return $fresh
                ? ['success' => true, 'room' => $fresh]
                : ['success' => false, 'errors' => ['Error al cargar la sala.']];
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            error_log('GameRoom::start error: ' . $e->getMessage());
            return ['success' => false, 'errors' => ['No se pudo iniciar la partida.']];
        }
    }

    /**
     * Returns null when the user is not a member of the room. When the room is no longer
     * playing the array carries the final status and end_reason with no players.
     */
    public function getState(int $roomId, int $userId): ?array
    {
        if ($roomId <= 0) {
            return null;
        }

        $stmt = $this->db->prepare('SELECT status, host_id, guest_id, end_reason FROM game_rooms WHERE id = ? LIMIT 1');
        $stmt->execute([$roomId]);
        $room = $stmt->fetch();
        if (!$room) {
            return null;
        }

        $hostId  = (int) $room['host_id'];
        $guestId = $room['guest_id'] !== null ? (int) $room['guest_id'] : 0;
        if ($userId !== $hostId && $userId !== $guestId) {
            return null;
        }

        if ($room['status'] !== 'playing') {
            return ['room_id' => $roomId, 'status' => $room['status'], 'end_reason' => $room['end_reason'], 'players' => []];
        }

        $stmt = $this->db->prepare(
            'SELECT user_id, player_slot, pos_x, pos_y, pos_z, rot_y, last_seen
             FROM game_room_players WHERE room_id = ? ORDER BY player_slot ASC'
        );
        $stmt->execute([$roomId]);
        $rows = $stmt->fetchAll();

        $nowU    = microtime(true);
        $players = [];
        $stale   = count($rows) < 2;

        foreach ($rows as $row) {
            $age = max(0.0, $nowU - $this->unix($row['last_seen']));
            if ($age > self::PLAYING_STALE_SECONDS) {
                $stale = true;
            }
            $players[] = [
                'user_id' => (int) $row['user_id'],
                'slot'    => (int) $row['player_slot'],
                'x'       => (float) $row['pos_x'],
                'y'       => (float) $row['pos_y'],
                'z'       => (float) $row['pos_z'],
                'rotY'    => (float) $row['rot_y'],
                'age_ms'  => (int) round($age * 1000),
            ];
        }

        if ($stale) {
            $this->cancelRoom($roomId, 'timeout');
            return ['room_id' => $roomId, 'status' => 'cancelled', 'end_reason' => 'timeout', 'players' => []];
        }

        return ['room_id' => $roomId, 'status' => 'playing', 'end_reason' => null, 'players' => $players];
    }

    public function updatePlayerState(int $roomId, int $userId, float $x, float $y, float $z, float $rotY): bool
    {
        if ($roomId <= 0 || !is_finite($x) || !is_finite($y) || !is_finite($z) || !is_finite($rotY)) {
            return false;
        }

        $stmt = $this->db->prepare(
            "SELECT p.pos_x, p.pos_z, p.last_seen
             FROM game_room_players p
             JOIN game_rooms r ON r.id = p.room_id
             WHERE p.room_id = ? AND p.user_id = ? AND r.status = 'playing'
             LIMIT 1"
        );
        $stmt->execute([$roomId, $userId]);
        $prev = $stmt->fetch();
        if (!$prev) {
            return false;
        }

        $nowU = microtime(true);
        $dt   = $nowU - $this->unix($prev['last_seen']);
        if ($dt < self::MIN_UPDATE_INTERVAL) {
            return true;
        }

        $x    = max(-1000.0, min(1000.0, $x));
        $y    = max(0.0, min(1000.0, $y));
        $z    = max(-1000.0, min(1000.0, $z));
        $rotY = max(-100000.0, min(100000.0, $rotY));

        $px      = (float) $prev['pos_x'];
        $pz      = (float) $prev['pos_z'];
        $maxStep = self::MAX_SPEED * min($dt, self::MAX_STEP_SECONDS) + 0.5;
        $dx      = $x - $px;
        $dz      = $z - $pz;
        $dist    = hypot($dx, $dz);
        if ($dist > $maxStep) {
            $k = $maxStep / $dist;
            $x = $px + $dx * $k;
            $z = $pz + $dz * $k;
        }

        $upd = $this->db->prepare(
            'UPDATE game_room_players
             SET pos_x = ?, pos_y = ?, pos_z = ?, rot_y = ?, last_seen = ?
             WHERE room_id = ? AND user_id = ?'
        );
        $upd->execute([$x, $y, $z, $rotY, $this->ts($nowU), $roomId, $userId]);

        return true;
    }

    public function findById(int $id): ?array
    {
        $stmt = $this->db->prepare(self::SELECT_ROOM . ' WHERE r.id = ? LIMIT 1');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ? $this->enrich($row) : null;
    }

    public function findByCode(string $code): ?array
    {
        $stmt = $this->db->prepare(self::SELECT_ROOM . ' WHERE r.code = ? LIMIT 1');
        $stmt->execute([strtoupper(trim($code))]);
        $row = $stmt->fetch();
        return $row ? $this->enrich($row) : null;
    }

    public function findActiveByUser(int $userId): ?array
    {
        $stmt = $this->db->prepare(
            self::SELECT_ROOM . "
             WHERE (r.host_id = ? OR r.guest_id = ?) AND r.status IN ('waiting', 'ready', 'playing')
             ORDER BY r.updated_at DESC LIMIT 1"
        );
        $stmt->execute([$userId, $userId]);
        $row = $stmt->fetch();
        if (!$row) {
            return null;
        }

        return $this->enrich($this->maybeAutoStartQuick($row));
    }

    private function mergeIntoOlderQuickRoom(array $mine, int $userId): ?array
    {
        $stmt = $this->db->prepare(
            "SELECT code FROM game_rooms
             WHERE status = 'waiting' AND match_type = 'quick' AND guest_id IS NULL
               AND host_id <> ? AND id < ?
             ORDER BY id ASC LIMIT 1"
        );
        $stmt->execute([$userId, (int) $mine['id']]);
        $older = $stmt->fetch();
        if (!$older) {
            return null;
        }

        $joined = $this->join($userId, $older['code'], true);
        if ($joined['success']) {
            return $joined['room'];
        }

        $created = $this->create($userId, 'quick');
        return $created['success'] ? $created['room'] : null;
    }

    private function maybeAutoStartQuick(array $row): array
    {
        if (($row['match_type'] ?? 'code') !== 'quick' || $row['status'] !== 'ready') {
            return $row;
        }
        if (empty($row['auto_start_at']) || $row['auto_start_at'] > $this->now()) {
            return $row;
        }

        $this->start((int) $row['host_id'], (int) $row['id']);

        $stmt = $this->db->prepare(self::SELECT_ROOM . ' WHERE r.id = ? LIMIT 1');
        $stmt->execute([(int) $row['id']]);
        return $stmt->fetch() ?: $row;
    }

    private function leaveAllActive(int $userId): void
    {
        if ($this->findActiveByUser($userId)) {
            $this->leave($userId);
        }
    }

    private function touchLobby(int $userId): void
    {
        $seen = $this->nowMs();
        $this->db->prepare("UPDATE game_rooms SET host_seen = ? WHERE host_id = ? AND status IN ('waiting', 'ready')")
            ->execute([$seen, $userId]);
        $this->db->prepare("UPDATE game_rooms SET guest_seen = ? WHERE guest_id = ? AND status = 'ready'")
            ->execute([$seen, $userId]);
    }

    private function cancelRoom(int $roomId, string $reason): void
    {
        $now = $this->now();
        $this->db->prepare(
            "UPDATE game_rooms
             SET status = 'cancelled', auto_start_at = NULL, end_reason = ?, updated_at = ?, finished_at = ?
             WHERE id = ? AND status IN ('waiting', 'ready', 'playing')"
        )->execute([$reason, $now, $now, $roomId]);

        $this->db->prepare('DELETE FROM game_room_players WHERE room_id = ?')->execute([$roomId]);
    }

    private function reapStale(): void
    {
        try {
            $now       = $this->now();
            $lobbyCut  = $this->ts(microtime(true) - self::LOBBY_STALE_SECONDS);
            $playCut   = $this->ts(microtime(true) - self::PLAYING_STALE_SECONDS);

            $this->db->prepare(
                "UPDATE game_rooms
                 SET status = 'cancelled', auto_start_at = NULL, end_reason = 'timeout', updated_at = ?, finished_at = ?
                 WHERE status IN ('waiting', 'ready') AND COALESCE(host_seen, updated_at) < ?"
            )->execute([$now, $now, $lobbyCut]);

            $this->db->prepare(
                "UPDATE game_rooms
                 SET guest_id = NULL, guest_seen = NULL, status = 'waiting', auto_start_at = NULL, updated_at = ?
                 WHERE status = 'ready' AND COALESCE(guest_seen, updated_at) < ?"
            )->execute([$now, $lobbyCut]);

            $this->db->prepare(
                "UPDATE game_rooms r
                 SET r.status = 'cancelled', r.end_reason = 'timeout', r.updated_at = ?, r.finished_at = ?
                 WHERE r.status = 'playing'
                   AND EXISTS (SELECT 1 FROM game_room_players p WHERE p.room_id = r.id AND p.last_seen < ?)"
            )->execute([$now, $now, $playCut]);

            $this->db->exec(
                "DELETE p FROM game_room_players p
                 JOIN game_rooms r ON r.id = p.room_id
                 WHERE r.status <> 'playing'"
            );

            if (random_int(1, 50) === 1) {
                $this->db->prepare(
                    "DELETE FROM game_rooms WHERE status IN ('cancelled', 'finished') AND updated_at < ?"
                )->execute([$this->ts(microtime(true) - 86400)]);
            }
        } catch (Throwable $e) {
            error_log('GameRoom::reapStale error: ' . $e->getMessage());
        }
    }

    private function initializePlayers(int $roomId, int $hostId, int $guestId, string $now): void
    {
        $stmt = $this->db->prepare(
            'INSERT INTO game_room_players
             (room_id, user_id, player_slot, pos_x, pos_y, pos_z, rot_y, last_seen)
             VALUES (?, ?, 1, -2, 0, 0, 0, ?),
                    (?, ?, 2, 2, 0, 0, 0, ?)
             ON DUPLICATE KEY UPDATE
                player_slot = VALUES(player_slot),
                last_seen = VALUES(last_seen)'
        );
        $stmt->execute([$roomId, $hostId, $now, $roomId, $guestId, $now]);
    }

    private function generateCode(): string
    {
        $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $max   = strlen($chars) - 1;
        $code  = '';
        for ($i = 0; $i < 6; $i++) {
            $code .= $chars[random_int(0, $max)];
        }
        return $code;
    }

    private function enrich(array $row): array
    {
        $matchType   = $row['match_type'] ?? 'code';
        $autoStartAt = $row['auto_start_at'] ?? null;

        $countdown = null;
        if ($matchType === 'quick' && $row['status'] === 'ready' && $autoStartAt) {
            $countdown = max(0, strtotime($autoStartAt . ' UTC') - time());
        }

        return [
            'id'            => (int) $row['id'],
            'code'          => $row['code'],
            'status'        => $row['status'],
            'match_type'    => $matchType,
            'host'          => ['id' => (int) $row['host_id'], 'nickname' => (string) ($row['host_nick'] ?? '')],
            'guest'         => $row['guest_id'] !== null
                ? ['id' => (int) $row['guest_id'], 'nickname' => (string) ($row['guest_nick'] ?? '')]
                : null,
            'is_full'       => $row['guest_id'] !== null,
            'auto_start_at' => $autoStartAt,
            'countdown'     => $countdown,
            'created_at'    => $row['created_at'],
            'updated_at'    => $row['updated_at'],
            'started_at'    => $row['started_at'],
        ];
    }

    private function now(): string
    {
        return utcNow();
    }

    private function nowMs(): string
    {
        return $this->ts(microtime(true));
    }

    private function ts(float $unix): string
    {
        $dt = DateTimeImmutable::createFromFormat('U.u', sprintf('%.6F', $unix));
        return ($dt ?: new DateTimeImmutable('now', new DateTimeZone('UTC')))->format('Y-m-d H:i:s.v');
    }

    private function unix(string $datetime): float
    {
        return (float) (new DateTimeImmutable($datetime, new DateTimeZone('UTC')))->format('U.u');
    }
}
