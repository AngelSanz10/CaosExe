<?php
/**
 * Authentication & session management
 * Handles registration, login, logout and session integrity.
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/LoginThrottle.php';

final class Auth
{
    private const DUMMY_HASH = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';

    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    /**
     * Start secure session
     */
    public static function startSession(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }

        sendSecurityHeaders();

        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');
        ini_set('session.cookie_httponly', '1');
        ini_set('session.cookie_samesite', 'Lax');
        ini_set('session.cookie_secure', isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? '1' : '0');
        ini_set('session.gc_maxlifetime', (string) SESSION_LIFETIME);

        session_name(SESSION_NAME);
        session_set_cookie_params([
            'lifetime' => SESSION_LIFETIME,
            'path'     => '/',
            'secure'   => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
            'httponly' => true,
            'samesite' => 'Lax',
        ]);

        session_start();
    }

    /**
     * Register a new user
     * @return array{success: bool, errors?: string[], user_id?: int}
     */
    public function register(string $email, string $nickname, string $password): array
    {
        $errors = [];

        $email    = trim(mb_strtolower($email));
        $nickname = trim($nickname);

        if (!isValidEmail($email)) {
            $errors[] = 'El correo electrónico no es válido.';
        }
        if (!isValidNickname($nickname)) {
            $errors[] = 'El nickname debe tener entre ' . NICKNAME_MIN_LENGTH . ' y ' . NICKNAME_MAX_LENGTH . ' caracteres y solo letras, números o guión bajo.';
        }
        if (!isValidPassword($password)) {
            $errors[] = 'La contraseña debe tener al menos ' . PASSWORD_MIN_LENGTH . ' caracteres.';
        }

        if ($errors) {
            return ['success' => false, 'errors' => $errors];
        }

        // Check uniqueness
        $stmt = $this->db->prepare('SELECT id FROM users WHERE email = ? OR nickname = ? LIMIT 1');
        $stmt->execute([$email, $nickname]);
        if ($stmt->fetch()) {
            return ['success' => false, 'errors' => ['El correo o el nickname ya están en uso.']];
        }

        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        $now = (new DateTimeImmutable('now', new DateTimeZone('UTC')))->format('Y-m-d H:i:s');

        $stmt = $this->db->prepare(
            'INSERT INTO users (email, nickname, password_hash, is_active, created_at, updated_at)
             VALUES (?, ?, ?, 1, ?, ?)'
        );
        $stmt->execute([$email, $nickname, $passwordHash, $now, $now]);

        return [
            'success' => true,
            'user_id' => (int) $this->db->lastInsertId(),
        ];
    }

    /**
     * Authenticate user and create session
     * @return array{success: bool, errors?: string[]}
     */
    public function login(string $email, string $password): array
    {
        $email = trim(mb_strtolower($email));

        if (!isValidEmail($email) || $password === '') {
            return ['success' => false, 'errors' => ['Credenciales inválidas.']];
        }

        $throttle = new LoginThrottle();
        if ($throttle->isBlocked($email)) {
            return ['success' => false, 'errors' => ['Demasiados intentos. Inténtalo de nuevo en unos minutos.']];
        }

        $stmt = $this->db->prepare(
            'SELECT id, email, nickname, password_hash, is_active, session_token
             FROM users WHERE email = ? LIMIT 1'
        );
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !(int) $user['is_active']) {
            // Timing-safe: always verify a dummy hash
            password_verify($password, self::DUMMY_HASH);
            $throttle->recordFailure($email);
            return ['success' => false, 'errors' => ['Credenciales inválidas.']];
        }

        if (!password_verify($password, $user['password_hash'])) {
            $throttle->recordFailure($email);
            return ['success' => false, 'errors' => ['Credenciales inválidas.']];
        }

        $throttle->clear($email);

        // Invalidate any previous session token for this user (single active session)
        // and clear leftover session data before binding the new identity.
        $_SESSION = [];

        // Regenerate session ID to prevent fixation / session fixation across tabs
        session_regenerate_id(true);

        $sessionToken = generateToken();
        $now = (new DateTimeImmutable('now', new DateTimeZone('UTC')))->format('Y-m-d H:i:s');

        $stmt = $this->db->prepare(
            'UPDATE users SET session_token = ?, last_login = ?, updated_at = ? WHERE id = ?'
        );
        $stmt->execute([$sessionToken, $now, $now, $user['id']]);

        // Store minimal, necessary data in session
        $_SESSION['user'] = [
            'id'            => (int) $user['id'],
            'email'         => $user['email'],
            'nickname'      => $user['nickname'],
            'session_token' => $sessionToken,
            'logged_in_at'  => $now,
        ];
        $_SESSION['is_authenticated'] = true;

        // Fresh CSRF for the new identity (prevents carrying previous user's token)
        unset($_SESSION[CSRF_TOKEN_NAME]);
        csrfToken();

        return ['success' => true];
    }

    /**
     * Validate current session against DB (token + active status)
     */
    public function validateSession(): bool
    {
        if (empty($_SESSION['is_authenticated']) || empty($_SESSION['user']['id']) || empty($_SESSION['user']['session_token'])) {
            return false;
        }

        $stmt = $this->db->prepare(
            'SELECT id, email, nickname, session_token, is_active
             FROM users WHERE id = ? LIMIT 1'
        );
        $stmt->execute([$_SESSION['user']['id']]);
        $user = $stmt->fetch();

        if (!$user || !(int) $user['is_active']) {
            $this->logout();
            return false;
        }

        if (!hash_equals($user['session_token'] ?? '', $_SESSION['user']['session_token'])) {
            $this->logout();
            return false;
        }

        // Refresh session data (in case nickname/email changed)
        $_SESSION['user']['email']    = $user['email'];
        $_SESSION['user']['nickname'] = $user['nickname'];

        return true;
    }

    /**
     * Check if user is currently authenticated
     */
    public function check(): bool
    {
        return $this->validateSession();
    }

    /**
     * Get current authenticated user data or null
     */
    public function user(): ?array
    {
        if (!$this->check()) {
            return null;
        }
        return $_SESSION['user'];
    }

    /**
     * Logout: invalidate token and destroy session
     */
    public function logout(): void
    {
        if (!empty($_SESSION['user']['id'])) {
            $stmt = $this->db->prepare('UPDATE users SET session_token = NULL, updated_at = ? WHERE id = ?');
            $stmt->execute([
                (new DateTimeImmutable('now', new DateTimeZone('UTC')))->format('Y-m-d H:i:s'),
                $_SESSION['user']['id'],
            ]);
        }

        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'] ?? '',
                $params['secure'],
                $params['httponly']
            );
        }
        session_destroy();
    }
}
