<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

final class LoginThrottle
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    public function isBlocked(string $email): bool
    {
        try {
            $since = $this->since();
            $byIp = $this->db->prepare('SELECT COUNT(*) FROM login_attempts WHERE ip = ? AND created_at >= ?');
            $byIp->execute([$this->ip(), $since]);
            if ((int) $byIp->fetchColumn() >= LOGIN_MAX_PER_IP) {
                return true;
            }

            $byEmail = $this->db->prepare('SELECT COUNT(*) FROM login_attempts WHERE email_hash = ? AND created_at >= ?');
            $byEmail->execute([$this->emailHash($email), $since]);
            return (int) $byEmail->fetchColumn() >= LOGIN_MAX_PER_EMAIL;
        } catch (Throwable $e) {
            error_log('LoginThrottle::isBlocked error: ' . $e->getMessage());
            return false;
        }
    }

    public function recordFailure(string $email): void
    {
        try {
            $this->db->prepare('INSERT INTO login_attempts (ip, email_hash, created_at) VALUES (?, ?, ?)')
                ->execute([$this->ip(), $this->emailHash($email), utcNow()]);

            if (random_int(1, 40) === 1) {
                $this->db->prepare('DELETE FROM login_attempts WHERE created_at < ?')
                    ->execute([$this->since(LOGIN_WINDOW_SECONDS * 6)]);
            }
        } catch (Throwable $e) {
            error_log('LoginThrottle::recordFailure error: ' . $e->getMessage());
        }
    }

    public function clear(string $email): void
    {
        try {
            $this->db->prepare('DELETE FROM login_attempts WHERE email_hash = ?')
                ->execute([$this->emailHash($email)]);
        } catch (Throwable $e) {
            error_log('LoginThrottle::clear error: ' . $e->getMessage());
        }
    }

    private function ip(): string
    {
        return (string) inet_pton(clientIp());
    }

    private function emailHash(string $email): string
    {
        return hash('sha256', $email);
    }

    private function since(int $seconds = LOGIN_WINDOW_SECONDS): string
    {
        return (new DateTimeImmutable('now', new DateTimeZone('UTC')))
            ->modify('-' . $seconds . ' seconds')
            ->format('Y-m-d H:i:s');
    }
}
