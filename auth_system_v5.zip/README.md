# Sistema de autenticación + emparejamiento cooperativo (2 jugadores)

Código de calidad, escalable y bien estructurado.

## Requisitos

- PHP 8.1+
- MySQL 8+ / MariaDB 10.5+
- Extensiones: `pdo_mysql`, `mbstring`

## Instalación

1. Base de datos nueva: importa `sql/schema.sql` (o `sql/schema_import.sql` si la BD ya existe y está vacía).
   Base de datos existente: ejecuta **una sola vez** `sql/migrate_v2.sql` (después de `migrate_quick_match.sql` si aún no lo habías aplicado).
2. Credenciales: copia `config/config.local.php.example` a `config/config.local.php` y rellénalo
   (o usa variables de entorno `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASS`). Ese archivo no está en git y `config/` está bloqueado por `.htaccess`.
3. Document root = directorio del proyecto.
4. Comprueba la sintaxis antes de subir: `find . -name '*.php' -print0 | xargs -0 -n1 php -l`

## Estructura

```
├── api/room.php              # API JSON (create/join/quick/leave/disconnect/start/update/state/status)
├── assets/css/style.css
├── config/
│   ├── config.php
│   └── database.php
├── includes/
│   ├── Auth.php
│   ├── GameRoom.php          # Lógica de salas y emparejamiento
│   ├── LoginThrottle.php     # Límite de intentos de login
│   └── functions.php
├── sql/                      # schema, schema_import, migrate_quick_match, migrate_v2
├── index.php                 # Landing pública
├── register.php / login.php
├── session.php               # Área autenticada
├── lobby.php                 # Emparejamiento (crear / unirse / rápida)
├── game.php                  # Entrada a partida (CSP + carga de módulos)
├── game/                     # main.js (escena), network.js (sondeo), telemetry.js (HUD)
└── logout.php
```

## Flujo de emparejamiento

1. Login → `session.php` → **Lobby**
2. Opciones:
   - **Partida rápida**: une a la primera sala en `waiting` o crea una nueva.
   - **Crear sala**: genera código de 6 caracteres, queda en `waiting`.
   - **Unirse con código**: el segundo jugador pasa la sala a `ready`.
3. Anfitrión pulsa **Iniciar** → status `playing`.
4. Ambos entran a `game.php` (punto de entrada para Three.js + WebGL).

Estados de sala: `waiting` → `ready` → `playing` → `finished` / `cancelled`.

## Seguridad

- Auth existente intacta (token de sesión en BD, CSRF, prepared statements…).
- API mutante protegida por sesión + CSRF.
- Solo host/guest de la sala pueden acceder a `game.php` en estado `playing`.
- Transacciones al unirse (evita race conditions de 3er jugador).
- Identity guard en lobby: si la cookie de sesión cambia (otro login en el mismo navegador), la página se recarga sola.
- Login limpia `$_SESSION` y rota CSRF al cambiar de identidad.

## Prueba con 2 jugadores

PHP usa una cookie de sesión por navegador (`GAME_SESSID`). **No puedes tener dos usuarios distintos en la misma ventana/perfil del navegador.**

Formas correctas de probar:
1. Navegador A (Chrome) + Navegador B (Firefox), o
2. Ventana normal + ventana privada/incógnito del mismo navegador.

Si inicias sesión del usuario B en otra pestaña del mismo perfil, la pestaña del usuario A pasa a ser B (comportamiento esperado de cookies compartidas).

## Anti-fantasmas (servidor)

- Cada sondeo del lobby actualiza `host_seen` / `guest_seen`; en partida, cada `update` actualiza `last_seen` (ms).
- Un reaper elimina salas con más de 20 s sin señal (`LOBBY_STALE_SECONDS`, `PLAYING_STALE_SECONDS`), las marca `cancelled` y guarda `end_reason` (`timeout`, `host_left`, `guest_left`).
- Cierre de pestaña/recarga: el `sendBeacon` llama a `disconnect`, que solo adelanta el reloj del jugador para dejarle 6 s de gracia. Si recarga (F5) vuelve a tiempo y no pierde la sala; si no vuelve, la sala se libera sola. El botón «Salir» y el logout sí llaman a `leave` de inmediato.
- Partida rápida: si dos jugadores buscan a la vez y crean salas separadas, el dueño de la sala más nueva se une a la más antigua en su siguiente sondeo.

## Seguridad añadida

- Credenciales fuera del código (`config.local.php`), `.htaccess` en `config/`, `includes/` y `sql/`.
- Límite de intentos de login por IP y por correo (`login_attempts`), hash dummy válido contra timing.
- Logout solo por POST + CSRF; libera la sala antes de destruir la sesión.
- Cabeceras `nosniff`, `X-Frame-Options`, `Referrer-Policy`; CSP con nonce en `game.php` (modo informe por defecto: pon `CSP_ENFORCE` a `true` en `config/config.php` cuando la consola no muestre violaciones).
- API: método y CSRF por acción, `session_write_close()` (sin bloqueo de sesión entre peticiones), respuestas de error con `code`, límite de frecuencia y de velocidad en `update`, pertenencia a la sala comprobada en servidor.

## Controles

- **WASD** (o flechas): desplazamiento en el plano horizontal, relativo a la dirección de la cámara (W avanza hacia donde mira la cámara). Se usa el código físico de la tecla, así que funciona igual con cualquier distribución.
- **Ratón**: clic en la escena para capturarlo (Pointer Lock); mover el ratón orbita la cámara con suavizado independiente de los FPS. **ESC** lo libera. Rueda: zoom.
- El personaje gira suavemente hacia su dirección de marcha (el cubo blanco indica el frente).
- Ajustes en `game/controls.js` (`sensitivity`, `smoothing`, límites de inclinación) y `game/main.js` (`SPEED`, `TURN_SMOOTH`, `FOLLOW_SMOOTH`). La velocidad máxima del servidor (9 u/s) deja margen sobre `SPEED` (5 u/s).

## Telemetría (F3 para ocultar/mostrar el detalle)

FPS y 1 % bajo, tiempo de frame, ping (mediana, mín/máx), jitter, tiempo de proceso en servidor, % de pérdida, antigüedad de los datos del rival, mensajes por segundo, draw calls/triángulos, geometrías/texturas vivas (detecta fugas) y heap JS (solo Chromium).

## Próximos pasos

- Interpolación de movimiento remoto para suavizar todavía más la red.
- Modelos FBX / GLTF.
- Acciones de juego y estado adicional de la partida.
- WebSocket cuando el despliegue tenga un servidor/proceso persistente adecuado.
