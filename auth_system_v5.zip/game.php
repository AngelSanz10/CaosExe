<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/Auth.php';
require_once __DIR__ . '/includes/GameRoom.php';

Auth::startSession();
$auth = new Auth();

if (!$auth->check()) {
    setFlash('error', 'Debes iniciar sesión.');
    redirect('login.php');
}

$user    = $auth->user();
$userId  = (int) $user['id'];
$rooms   = new GameRoom();
$request = (int) ($_GET['room'] ?? 0);
$room    = $request > 0 ? $rooms->findById($request) : $rooms->findActiveByUser($userId);

if (!$room || $room['status'] !== 'playing') {
    setFlash('info', 'No hay partida activa.');
    redirect('lobby.php');
}

$isPlayer = (int) ($room['host']['id'] ?? 0) === $userId
    || (int) ($room['guest']['id'] ?? 0) === $userId;

if (!$isPlayer || !$room['guest']) {
    setFlash('error', 'No perteneces a esta sala o falta el segundo jugador.');
    redirect('lobby.php');
}

$boot = [
    'roomId'    => (int) $room['id'],
    'userId'    => $userId,
    'hostId'    => (int) $room['host']['id'],
    'guestId'   => (int) $room['guest']['id'],
    'hostNick'  => $room['host']['nickname'],
    'guestNick' => $room['guest']['nickname'],
    'csrf'      => csrfToken(),
    'csrfName'  => CSRF_TOKEN_NAME,
];

$nonce = base64_encode(random_bytes(16));
$csp = implode('; ', [
    "default-src 'self'",
    "script-src 'self' 'nonce-{$nonce}' https://cdn.jsdelivr.net",
    "style-src 'self' 'nonce-{$nonce}'",
    "img-src 'self' data: blob:",
    "connect-src 'self'",
    "object-src 'none'",
    "base-uri 'none'",
    "form-action 'self'",
    "frame-ancestors 'none'",
]);
header((CSP_ENFORCE ? 'Content-Security-Policy' : 'Content-Security-Policy-Report-Only') . ': ' . $csp);
header('Cache-Control: no-store');
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sala <?= e($room['code']) ?></title>
<style nonce="<?= e($nonce) ?>">
html,body{margin:0;width:100%;height:100%;overflow:hidden;background:#090b10;color:#eef2f7;font-family:system-ui,sans-serif}
#game{position:fixed;inset:0}canvas{display:block}
#hud{position:fixed;top:18px;left:18px;z-index:5;min-width:260px;padding:14px 16px;border:1px solid #293140;border-radius:12px;background:rgba(13,17,24,.9);backdrop-filter:blur(8px)}
#hud h1{font-size:17px;margin:0 0 8px}.line{font-size:13px;color:#aeb8c7;margin:4px 0}.ok{color:#67d391}.warn{color:#f1c75b}.bad{color:#ff7a7a}
.player{display:flex;align-items:center;gap:8px;margin-top:8px}.dot{width:10px;height:10px;border-radius:50%;background:#61a7ff}
button{margin-top:10px;padding:8px 12px;border:1px solid #394456;border-radius:8px;background:#18202c;color:#fff;cursor:pointer}
#error{color:#ff8585;margin-top:7px;font-size:12px}
#lockhint{position:fixed;left:50%;bottom:28px;transform:translateX(-50%);z-index:5;padding:10px 18px;border:1px solid #293140;border-radius:999px;background:rgba(13,17,24,.88);font-size:13px;color:#eef2f7;pointer-events:none}
.hidden{display:none}
canvas{cursor:grab}
#telemetry{position:fixed;top:18px;right:18px;z-index:5;min-width:250px;padding:12px 14px;border:1px solid #293140;border-radius:12px;background:rgba(13,17,24,.85);font:12px ui-monospace,monospace;pointer-events:none}
.tele-summary{font-weight:700;font-size:13px;margin-bottom:6px}
.tele-table div{display:flex;justify-content:space-between;gap:14px;margin:2px 0;color:#aeb8c7}
.tele-table span:last-child{text-align:right;color:#eef2f7}
.tele-table span.ok{color:#67d391}.tele-table span.warn{color:#f1c75b}.tele-table span.bad{color:#ff7a7a}
.tele-hint{margin-top:6px;color:#6b7686;font-size:11px}
</style>
<script type="importmap" nonce="<?= e($nonce) ?>">{"imports":{"three":"https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js"}}</script>
</head>
<body>
<div id="game"></div>
<div id="hud">
  <h1>Sala <?= e($room['code']) ?> · 2 jugadores</h1>
  <div class="line" id="connection">Conectando…</div>
  <div class="player"><span class="dot"></span><span>Jugador 1: <?= e($room['host']['nickname']) ?></span></div>
  <div class="player"><span class="dot"></span><span>Jugador 2: <?= e($room['guest']['nickname']) ?></span></div>
  <div class="line">WASD mover · ratón mirar · rueda zoom · ESC libera el ratón</div>
  <button id="leave" type="button">Salir al lobby</button>
  <div id="error"></div>
</div>
<div id="lockhint">Haz clic en la escena para capturar el ratón</div>
<div id="telemetry"></div>
<script type="application/json" id="boot"><?= json_encode($boot, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR) ?></script>
<script type="module" src="game/main.js"></script>
</body>
</html>
