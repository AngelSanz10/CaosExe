<?php
/**
 * User registration
 */

declare(strict_types=1);

require_once __DIR__ . '/includes/Auth.php';

Auth::startSession();
$auth = new Auth();

if ($auth->check()) {
    redirect('session.php');
}

$errors = [];
$email = $nickname = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrf($_POST[CSRF_TOKEN_NAME] ?? null)) {
        $errors[] = 'Token de seguridad inválido. Recarga la página.';
    } else {
        $email    = trim($_POST['email'] ?? '');
        $nickname = trim($_POST['nickname'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm  = $_POST['password_confirm'] ?? '';

        if ($password !== $confirm) {
            $errors[] = 'Las contraseñas no coinciden.';
        } else {
            $result = $auth->register($email, $nickname, $password);
            if ($result['success']) {
                setFlash('success', 'Cuenta creada correctamente. Ya puedes iniciar sesión.');
                redirect('login.php');
            }
            $errors = $result['errors'] ?? ['Error desconocido.'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>Crear cuenta</h1>
            <p class="subtitle">Correo, nickname y contraseña.</p>

            <?php if ($errors): ?>
                <div class="alert alert-error">
                    <?php foreach ($errors as $err): ?>
                        <div><?= e($err) ?></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form method="post" action="" novalidate>
                <input type="hidden" name="<?= e(CSRF_TOKEN_NAME) ?>" value="<?= e(csrfToken()) ?>">

                <div class="form-group">
                    <label for="email">Correo electrónico</label>
                    <input type="email" id="email" name="email" value="<?= e($email) ?>" required autocomplete="email">
                </div>

                <div class="form-group">
                    <label for="nickname">Nickname</label>
                    <input type="text" id="nickname" name="nickname" value="<?= e($nickname) ?>" required
                           minlength="<?= NICKNAME_MIN_LENGTH ?>" maxlength="<?= NICKNAME_MAX_LENGTH ?>"
                           pattern="[a-zA-Z0-9_]+" autocomplete="username">
                </div>

                <div class="form-group">
                    <label for="password">Contraseña</label>
                    <input type="password" id="password" name="password" required
                           minlength="<?= PASSWORD_MIN_LENGTH ?>" autocomplete="new-password">
                </div>

                <div class="form-group">
                    <label for="password_confirm">Confirmar contraseña</label>
                    <input type="password" id="password_confirm" name="password_confirm" required
                           minlength="<?= PASSWORD_MIN_LENGTH ?>" autocomplete="new-password">
                </div>

                <button type="submit" class="btn">Registrarse</button>
            </form>

            <div class="links">
                ¿Ya tienes cuenta? <a href="login.php">Inicia sesión</a>
            </div>
        </div>
    </div>
</body>
</html>
