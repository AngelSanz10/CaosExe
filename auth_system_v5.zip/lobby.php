<?php
/**
 * Lobby – matching & room management for cooperative 2-player game
 */

declare(strict_types=1);

require_once __DIR__ . '/includes/Auth.php';
require_once __DIR__ . '/includes/GameRoom.php';

Auth::startSession();
$auth = new Auth();

if (!$auth->check()) {
    setFlash('error', 'Debes iniciar sesión para acceder.');
    redirect('login.php');
}

$user = $auth->user();
$roomManager = new GameRoom();
$currentRoom = $roomManager->findActiveByUser((int) $user['id']);
$csrf = csrfToken();

$notices = [
    'room_closed' => ['info', 'La partida terminó porque el otro jugador salió o perdió la conexión.'],
    'network'     => ['error', 'Se perdió la conexión con el servidor.'],
    'session'     => ['error', 'Tu sesión ha expirado.'],
    'csrf'        => ['error', 'Token de seguridad inválido. Se recargó la página.'],
    'identity'    => ['error', 'La sesión cambió en otra pestaña.'],
    'forbidden'   => ['error', 'No perteneces a esa sala.'],
];
$reason = is_string($_GET['reason'] ?? null) ? $_GET['reason'] : '';
$flash  = getFlash();
$notice = $flash
    ? ['type' => $flash['type'], 'message' => $flash['message']]
    : (isset($notices[$reason]) ? ['type' => $notices[$reason][0], 'message' => $notices[$reason][1]] : null);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lobby – Emparejamiento</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .container { max-width: 480px; }
        .room-code { font-size: 2rem; letter-spacing: 0.35em; font-weight: 700; font-family: monospace; }
        .player-slot { padding: 0.75rem 1rem; border-radius: 8px; background: #1a1a2e; margin-bottom: 0.5rem; display: flex; justify-content: space-between; align-items: center; }
        .player-slot.empty { opacity: 0.5; border: 1px dashed #444; }
        .status-waiting { color: #f0ad4e; }
        .status-ready { color: #5cb85c; }
        .status-playing { color: #5bc0de; }
        .actions { display: flex; flex-wrap: wrap; gap: 0.5rem; margin-top: 1.25rem; }
        .actions .btn { flex: 1; min-width: 120px; width: auto; }
        .join-block { margin-top: 1.25rem; }
        .join-block label {
            display: block;
            margin-bottom: 0.4rem;
            font-size: 0.875rem;
            color: #9aa0a6;
        }
        #join-form {
            display: flex;
            flex-direction: row;
            align-items: stretch;
            gap: 0.5rem;
            width: 100%;
        }
        #join-code {
            flex: 1 1 auto;
            min-width: 0;
            width: auto;
            max-width: none;
            box-sizing: border-box;
            padding: 0.75rem 1rem;
            font-size: 1.15rem;
            font-family: ui-monospace, monospace;
            letter-spacing: 0.28em;
            text-transform: uppercase;
            text-align: center;
            background: #0f1115;
            border: 1px solid #2a2f3a;
            border-radius: 8px;
            color: #e8eaed;
        }
        #join-code:focus {
            outline: none;
            border-color: #4f8cff;
        }
        #btn-join {
            flex: 0 0 auto;
            width: auto;
            min-width: 96px;
            padding: 0.75rem 1.1rem;
        }
        .linkbtn { background: none; border: 0; padding: 0; color: var(--primary); cursor: pointer; font: inherit; }
        .poll-hint { font-size: 0.8rem; color: #888; margin-top: 1rem; }
        .test-hint { font-size: 0.75rem; color: #666; margin-top: 1.25rem; padding: 0.6rem 0.8rem; background: #141422; border-radius: 6px; border-left: 3px solid #555; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>Lobby</h1>
            <p class="subtitle">
                Hola, <strong id="nick-display"><?= e($user['nickname']) ?></strong> —
                emparejamiento cooperativo (2 jugadores)
            </p>

            <?php if ($notice): ?>
                <div class="alert alert-<?= e($notice['type']) ?>"><?= e($notice['message']) ?></div>
            <?php endif; ?>

            <div id="lobby-root">
                <!-- filled by JS -->
            </div>

            <p class="test-hint">
                Para probar dos jugadores a la vez usa <strong>dos navegadores distintos</strong>
                o una ventana normal + una ventana privada. El mismo navegador comparte la cookie de sesión.
            </p>

            <div class="links" style="margin-top: 1.5rem;">
                <a href="session.php">← Volver a sesión</a> ·
                <form method="post" action="logout.php" style="display:inline">
                    <input type="hidden" name="<?= e(CSRF_TOKEN_NAME) ?>" value="<?= e($csrf) ?>">
                    <button type="submit" class="linkbtn">Cerrar sesión</button>
                </form>
            </div>
        </div>
    </div>

    <script>
        const CSRF = <?= json_encode($csrf) ?>;
        const CSRF_NAME = <?= json_encode(CSRF_TOKEN_NAME) ?>;
        const USER_ID = <?= (int) $user['id'] ?>;
        const USER_NICK = <?= json_encode($user['nickname'], JSON_UNESCAPED_UNICODE) ?>;
        const root = document.getElementById('lobby-root');
        let pollTimer = null;
        let busy = false;
        let isLeaving = false;
        let isEnteringGame = false;
        let currentRoomId = null;
        let lastRenderKey = null;
        let draftJoinCode = '';
        let countdownTimer = null;
        let refreshing = false;

        if (location.search) history.replaceState(null, '', 'lobby.php');

        function stopLocalCountdown() {
            if (countdownTimer) {
                clearInterval(countdownTimer);
                countdownTimer = null;
            }
        }

        function startLocalCountdown(seconds) {
            stopLocalCountdown();
            let left = Math.max(0, Math.ceil(Number(seconds) || 0));
            const tick = () => {
                const el = document.getElementById('countdown-num');
                if (el) el.textContent = String(left);
                if (left <= 0) {
                    stopLocalCountdown();
                    return;
                }
                left -= 1;
            };
            tick();
            countdownTimer = setInterval(tick, 1000);
        }

        function stopPolling() {
            if (pollTimer) {
                clearInterval(pollTimer);
                pollTimer = null;
            }
        }

        function forceReload(reason) {
            stopPolling();
            stopLocalCountdown();
            let reloads = 0;
            try {
                const now = Date.now();
                const recent = JSON.parse(sessionStorage.getItem('lobbyReloads') || '[]').filter((t) => now - t < 10000);
                recent.push(now);
                sessionStorage.setItem('lobbyReloads', JSON.stringify(recent));
                reloads = recent.length;
            } catch (_) {}
            if (reloads > 3) {
                root.innerHTML = '<div class="alert alert-error">No se puede restablecer la conexión. Recarga la página o vuelve a iniciar sesión.</div>';
                return;
            }
            const q = reason ? ('?reason=' + encodeURIComponent(reason)) : '';
            window.location.replace('lobby.php' + q);
        }

        function enterGame(roomId) {
            isEnteringGame = true;
            stopLocalCountdown();
            stopPolling();
            window.location.replace('game.php?room=' + encodeURIComponent(roomId));
        }

        function sendLeaveBeacon() {
            if (!currentRoomId || isEnteringGame || isLeaving) return;
            const body = new FormData();
            body.append('action', 'disconnect');
            body.append(CSRF_NAME, CSRF);
            navigator.sendBeacon('api/room.php?action=disconnect', body);
            currentRoomId = null;
        }

        async function api(action, extra = {}) {
            const isStatus = action === 'status';
            const opts = {
                method: isStatus ? 'GET' : 'POST',
                credentials: 'same-origin',
                cache: 'no-store',
            };

            if (!isStatus) {
                const body = new FormData();
                body.append('action', action);
                body.append(CSRF_NAME, CSRF);
                for (const [k, v] of Object.entries(extra)) {
                    body.append(k, String(v));
                }
                opts.body = body;
            }

            const res = await fetch('api/room.php?action=' + encodeURIComponent(action), opts);

            if (res.status === 401) {
                forceReload('session');
                return { success: false, errors: ['Sesión expirada.'] };
            }
            if (res.status === 403) {
                forceReload('csrf');
                return { success: false, errors: ['Token de seguridad inválido. Recargando…'] };
            }

            let data;
            try {
                data = await res.json();
            } catch (_) {
                return { success: false, errors: ['Respuesta inválida del servidor.'] };
            }

            if (data.user && Number(data.user.id) !== USER_ID) {
                forceReload('identity');
                return { success: false, errors: ['La sesión cambió. Recargando…'] };
            }

            return data;
        }

        function statusClass(s) {
            return 'status-' + s;
        }

        function esc(s) {
            const d = document.createElement('div');
            d.textContent = s ?? '';
            return d.innerHTML;
        }

        function bindIdleControls() {
            document.getElementById('btn-quick').onclick = () => doAction('quick');
            document.getElementById('btn-create').onclick = () => doAction('create');
            const joinInput = document.getElementById('join-code');
            if (!joinInput) return;

            // Restore what the user was typing (polling must not wipe it).
            if (draftJoinCode && !joinInput.value) {
                joinInput.value = draftJoinCode;
            }

            const doJoin = () => {
                const code = joinInput.value.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
                joinInput.value = code;
                draftJoinCode = code;
                if (code.length === 6) {
                    doAction('join', { code });
                } else {
                    const msg = document.getElementById('msg');
                    if (msg) {
                        msg.innerHTML = '<div class="alert alert-error">El código debe tener 6 caracteres.</div>';
                    }
                }
            };

            document.getElementById('btn-join').onclick = doJoin;
            joinInput.oninput = () => {
                joinInput.value = joinInput.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
                draftJoinCode = joinInput.value;
            };
            joinInput.onkeydown = (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    doJoin();
                }
            };
        }

        function render(room) {
            if (isLeaving) {
                room = null;
            }

            // Preserve typed code before any DOM rebuild.
            const existingInput = document.getElementById('join-code');
            if (existingInput) {
                draftJoinCode = existingInput.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
            }

            currentRoomId = room ? Number(room.id) : null;

            // Avoid full re-render on idle polls — that was clearing the join code every 2s.
            const matchType = room?.match_type || 'code';
            const renderKey = room
                ? ['room', room.id, room.status, matchType, room.host?.id || 0, room.guest?.id || 0].join(':')
                : 'idle';
            if (renderKey === lastRenderKey) {
                return;
            }
            lastRenderKey = renderKey;
            stopLocalCountdown();

            if (!room) {
                root.innerHTML = `
                    <p>No estás en ninguna sala.</p>
                    <div class="actions">
                        <button class="btn" id="btn-quick" type="button">Partida rápida</button>
                        <button class="btn btn-secondary" id="btn-create" type="button">Crear sala</button>
                    </div>
                    <div class="join-block">
                        <label for="join-code">Unirse con código de sala</label>
                        <div id="join-form">
                            <input type="text" id="join-code" name="join_code" maxlength="6" minlength="6"
                                placeholder="ABC123" autocomplete="off" spellcheck="false"
                                inputmode="text" autocapitalize="characters"
                                value="${esc(draftJoinCode)}">
                            <button class="btn btn-secondary" id="btn-join" type="button">Unirse</button>
                        </div>
                    </div>
                    <div id="msg"></div>
                `;
                bindIdleControls();
                return;
            }

            const isHost = room.host && Number(room.host.id) === USER_ID;
            const isQuick = matchType === 'quick';
            const guestSlot = room.guest
                ? `<div class="player-slot"><span>${esc(room.guest.nickname)}</span><span>Jugador 2</span></div>`
                : `<div class="player-slot empty"><span>${isQuick ? 'Buscando rival…' : 'Esperando jugador…'}</span><span>—</span></div>`;

            let actions = `<button class="btn btn-secondary" id="btn-leave" type="button">Salir de la sala</button>`;
            // Manual start only for code rooms. Quick match auto-starts in 3s.
            if (!isQuick && isHost && room.status === 'ready') {
                actions = `<button class="btn" id="btn-start" type="button">Iniciar partida</button>` + actions;
            }
            if (room.status === 'playing') {
                actions = `<button class="btn" id="btn-enter" type="button">Entrar al juego</button>` + actions;
            }

            let header = '';
            if (isQuick) {
                header = `
                    <p>Partida rápida</p>
                    <p class="${statusClass(room.status)}" style="margin: 0.75rem 0;">
                        ${room.status === 'waiting'
                            ? 'Esperando a que otro jugador pulse <strong>Partida rápida</strong>…'
                            : room.status === 'ready'
                                ? `Rival encontrado · la partida empieza en <strong id="countdown-num">${esc(String(room.countdown ?? 3))}</strong> s`
                                : `Estado: <strong>${esc(room.status)}</strong>`}
                    </p>
                `;
            } else {
                header = `
                    <p>Código de sala</p>
                    <div class="room-code">${esc(room.code)}</div>
                    <p class="${statusClass(room.status)}" style="margin: 0.75rem 0;">
                        Estado: <strong>${esc(room.status)}</strong>
                    </p>
                `;
            }

            root.innerHTML = `
                ${header}
                <div class="player-slot">
                    <span>${esc(room.host?.nickname || '?')}</span>
                    <span>Anfitrión</span>
                </div>
                ${guestSlot}
                <div class="actions">${actions}</div>
                <p class="poll-hint">Actualización automática cada 2 s</p>
                <div id="msg"></div>
            `;

            if (isQuick && room.status === 'ready') {
                startLocalCountdown(room.countdown ?? 3);
            }

            const leaveBtn = document.getElementById('btn-leave');
            if (leaveBtn) leaveBtn.onclick = () => doLeave();
            const startBtn = document.getElementById('btn-start');
            if (startBtn) startBtn.onclick = () => doAction('start', { room_id: room.id });
            const enterBtn = document.getElementById('btn-enter');
            if (enterBtn) enterBtn.onclick = () => enterGame(room.id);
        }

        async function doLeave() {
            if (busy || isLeaving || isEnteringGame) return;
            isLeaving = true;
            busy = true;
            stopLocalCountdown();
            stopPolling();
            const msg = document.getElementById('msg');
            if (msg) msg.textContent = 'Saliendo…';
            try {
                const data = await api('leave');
                if (!data.success) {
                    isLeaving = false;
                    if (msg) {
                        msg.innerHTML = `<div class="alert alert-error">${(data.errors || ['Error']).map(esc).join('<br>')}</div>`;
                    }
                    startPolling();
                    return;
                }
                currentRoomId = null;
                lastRenderKey = null;
                draftJoinCode = '';
                render(null);
                startPolling();
            } catch (_) {
                isLeaving = false;
                if (msg) msg.innerHTML = `<div class="alert alert-error">Error de red</div>`;
                startPolling();
            } finally {
                busy = false;
                isLeaving = false;
            }
        }

        async function doAction(action, extra = {}) {
            if (busy || isLeaving || isEnteringGame) return;
            if (action === 'leave') {
                await doLeave();
                return;
            }
            busy = true;
            const msg = document.getElementById('msg');
            if (msg) msg.textContent = '…';
            try {
                const data = await api(action, extra);
                if (!data.success) {
                    if (msg) {
                        msg.innerHTML = `<div class="alert alert-error">${(data.errors || ['Error']).map(esc).join('<br>')}</div>`;
                    }
                    return;
                }
                if (action === 'join' || action === 'create' || action === 'quick') {
                    draftJoinCode = '';
                }
                // After start, prefer room from response and enter immediately.
                if (action === 'start' && data.room && data.room.status === 'playing') {
                    lastRenderKey = null;
                    render(data.room);
                    enterGame(data.room.id);
                    return;
                }
                lastRenderKey = null;
                await refresh();
            } catch (e) {
                if (msg) msg.innerHTML = `<div class="alert alert-error">Error de red</div>`;
            } finally {
                busy = false;
            }
        }

        async function refresh() {
            if (isLeaving || isEnteringGame || refreshing) return;
            refreshing = true;
            try {
                const data = await api('status');
                if (isLeaving || isEnteringGame) return;
                if (data.success) {
                    if (data.user && data.user.nickname) {
                        const el = document.getElementById('nick-display');
                        if (el) el.textContent = data.user.nickname;
                    }
                    render(data.room);
                    if (data.room && data.room.status === 'playing') {
                        enterGame(data.room.id);
                        return;
                    }
                }
            } catch (_) {
            } finally {
                refreshing = false;
            }
        }

        function startPolling() {
            if (isLeaving || isEnteringGame) return;
            stopPolling();
            pollTimer = setInterval(refresh, 2000);
        }

        function onPageExit() {
            if (currentRoomId && !isLeaving && !isEnteringGame) {
                sendLeaveBeacon();
            }
        }
        window.addEventListener('beforeunload', onPageExit);
        window.addEventListener('pagehide', onPageExit);
        window.addEventListener('pageshow', (e) => {
            if (e.persisted) window.location.reload();
        });

        render(<?= $currentRoom ? json_encode($currentRoom, JSON_UNESCAPED_UNICODE) : 'null' ?>);
        startPolling();
    </script>
</body>
</html>
