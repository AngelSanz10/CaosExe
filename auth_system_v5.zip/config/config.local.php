<?php

declare(strict_types=1);

if (basename($_SERVER['PHP_SELF'] ?? '') === basename(__FILE__)) {
    http_response_code(403);
    exit;
}

define('DB_HOST', 'sql304.infinityfree.com');
define('DB_PORT', '3306');
define('DB_NAME', 'if0_43033376_game_auth');
define('DB_USER', 'if0_43033376');
define('DB_PASS', 'a29s6r2002');
