<?php
/**
 * Application configuration
 */

declare(strict_types=1);

// Prevent direct access
if (basename($_SERVER['PHP_SELF']) === basename(__FILE__)) {
    http_response_code(403);
    exit('Direct access not allowed.');
}

// Environment
define('APP_ENV', getenv('APP_ENV') ?: 'production');
define('APP_DEBUG', APP_ENV === 'development');

// Secrets live in config/config.local.php (never served over HTTP, see .htaccess)
$localConfig = __DIR__ . '/config.local.php';
if (is_file($localConfig)) {
    require $localConfig;
}

foreach (['DB_HOST' => 'localhost', 'DB_PORT' => '3306', 'DB_NAME' => '', 'DB_USER' => '', 'DB_PASS' => ''] as $const => $default) {
    if (!defined($const)) {
        define($const, getenv($const) !== false ? (string) getenv($const) : $default);
    }
}
define('DB_CHARSET', 'utf8mb4');

// Session
define('SESSION_NAME', 'GAME_SESSID');
define('SESSION_LIFETIME', 60 * 60 * 24 * 7); // 7 days
define('SESSION_TOKEN_BYTES', 32);

// Security
define('CSP_ENFORCE', false); // true = bloquea; false = solo informa en consola
define('LOGIN_MAX_PER_IP', 15);
define('LOGIN_MAX_PER_EMAIL', 8);
define('LOGIN_WINDOW_SECONDS', 600);
define('CSRF_TOKEN_NAME', '_csrf_token');
define('PASSWORD_MIN_LENGTH', 8);
define('NICKNAME_MIN_LENGTH', 3);
define('NICKNAME_MAX_LENGTH', 32);

// Paths
define('BASE_PATH', dirname(__DIR__));
define('BASE_URL', '/'); // App en la raíz del dominio

// Timezone
date_default_timezone_set('UTC');

// Error reporting
if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
}
