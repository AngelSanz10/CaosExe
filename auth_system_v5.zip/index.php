<?php
/**
 * Public landing page
 * Always accessible. Redirects authenticated users to session.php
 */

declare(strict_types=1);

require_once __DIR__ . '/includes/Auth.php';

Auth::startSession();
$auth = new Auth();

if ($auth->check()) {
    redirect('session.php');
}

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>Bienvenido</h1>
            <p class="subtitle">Sistema de autenticación listo para el juego cooperativo.</p>

            <?php if ($flash): ?>
                <div class="alert alert-<?= e($flash['type']) ?>">
                    <?= e($flash['message']) ?>
                </div>
            <?php endif; ?>

            <a href="login.php" class="btn" style="margin-bottom: 0.75rem;">Iniciar sesión</a>
            <a href="register.php" class="btn btn-secondary">Crear cuenta</a>
        </div>
    </div>
</body>
</html>
