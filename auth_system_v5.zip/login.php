<?php
/**
 * User login
 */

declare(strict_types=1);

require_once __DIR__ . '/includes/Auth.php';

Auth::startSession();
$auth = new Auth();

if ($auth->check()) {
    redirect('session.php');
}

$errors = [];
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrf($_POST[CSRF_TOKEN_NAME] ?? null)) {
        $errors[] = 'Token de seguridad inválido. Recarga la página.';
    } else {
        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        $result = $auth->login($email, $password);
        if ($result['success']) {
            redirect('session.php');
        }
        $errors = $result['errors'] ?? ['Error desconocido.'];
    }
}

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar sesión</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>Iniciar sesión</h1>
            <p class="subtitle">Accede con tu correo y contraseña.</p>

            <?php if ($flash): ?>
                <div class="alert alert-<?= e($flash['type']) ?>">
                    <?= e($flash['message']) ?>
                </div>
            <?php endif; ?>

            <?php if ($errors): ?>
                <div class="alert alert-error">
                    <?php foreach ($errors as $err): ?>
                        <div><?= e($err) ?></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form method="post" action="" novalidate>
                <input type="hidden" name="<?= e(CSRF_TOKEN_NAME) ?>" value="<?= e(csrfToken()) ?>">

                <div class="form-group">
                    <label for="email">Correo electrónico</label>
                    <input type="email" id="email" name="email" value="<?= e($email) ?>" required autocomplete="email">
                </div>

                <div class="form-group">
                    <label for="password">Contraseña</label>
                    <input type="password" id="password" name="password" required autocomplete="current-password">
                </div>

                <button type="submit" class="btn">Entrar</button>
            </form>

            <div class="links">
                ¿No tienes cuenta? <a href="register.php">Regístrate</a>
            </div>
        </div>
    </div>
</body>
</html>
